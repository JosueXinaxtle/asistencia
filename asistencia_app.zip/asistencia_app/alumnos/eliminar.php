<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/funciones.php';
requerirLogin();

$pdo = conectarDB();
$id = (int)($_GET['id'] ?? 0);

try {
    $stmt = $pdo->prepare("DELETE FROM alumnos WHERE id = ?");
    $stmt->execute([$id]);
    redirigirConExito('index.php', 'Alumno eliminado correctamente.');
} catch (PDOException $e) {
    redirigirConError('index.php', 'No se pudo eliminar el alumno.');
}
