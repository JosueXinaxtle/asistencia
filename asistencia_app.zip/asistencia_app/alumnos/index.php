<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/funciones.php';
requerirLogin();

$pdo = conectarDB();

$tituloPagina = 'Alumnos';
require __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
  <h3 class="titulo-seccion mb-0">Alumnos</h3>
  <a href="agregar.php" class="btn btn-primary"><i class="fa-solid fa-user-plus"></i> Agregar alumno</a>
</div>

<?php mostrarMensaje(); ?>

<div class="card mb-3">
  <div class="card-body">
    <div class="input-group">
      <span class="input-group-text bg-white"><i class="fa-solid fa-magnifying-glass"></i></span>
      <input type="text" id="buscadorAlumnos" data-base="../" class="form-control"
             placeholder="Buscar por nombre, matrícula, grupo o especialidad...">
    </div>
  </div>
</div>

<div class="card">
  <div class="table-responsive">
    <table class="table table-hover mb-0">
      <thead>
        <tr>
          <th>Matrícula</th>
          <th>Nombre</th>
          <th>Turno</th>
          <th>Especialidad</th>
          <th>Grupo</th>
          <th>Materia(s)</th>
          <th>Profesor(es)</th>
          <th>Acciones</th>
        </tr>
      </thead>
      <tbody id="cuerpoTablaAlumnos">
        <?= filaAlumnosHTML($pdo) ?>
      </tbody>
    </table>
  </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
