<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/funciones.php';
requerirLogin();

$pdo = conectarDB();
$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);

$stmt = $pdo->prepare("SELECT * FROM alumnos WHERE id = ?");
$stmt->execute([$id]);
$alumno = $stmt->fetch();

if (!$alumno) {
    redirigirConError('index.php', 'Alumno no encontrado.');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $matricula   = limpiar($_POST['matricula'] ?? '');
    $nombre      = limpiar($_POST['nombre'] ?? '');
    $turno       = limpiar($_POST['turno'] ?? '');
    $especialidad = limpiar($_POST['especialidad'] ?? '');
    $grupo       = limpiar($_POST['grupo'] ?? '');
    $telefono    = limpiar($_POST['telefono'] ?? '');
    $tutor       = limpiar($_POST['tutor'] ?? '');
    $materias    = $_POST['materias'] ?? [];

    if ($nombre === '' || $turno === '' || $especialidad === '' || $grupo === '') {
        $error = 'Completa los campos obligatorios: nombre, turno, especialidad y grupo.';
    } else {
        try {
            $pdo->beginTransaction();
            $stmt = $pdo->prepare("UPDATE alumnos SET matricula=?, nombre=?, turno=?, especialidad=?, grupo=?, telefono=?, tutor=? WHERE id=?");
            $stmt->execute([$matricula ?: null, $nombre, $turno, $especialidad, $grupo, $telefono, $tutor, $id]);

            $pdo->prepare("DELETE FROM inscripciones WHERE alumno_id = ?")->execute([$id]);
            if (!empty($materias)) {
                $stmtIns = $pdo->prepare("INSERT IGNORE INTO inscripciones (alumno_id, materia_id) VALUES (?, ?)");
                foreach ($materias as $materiaId) {
                    $stmtIns->execute([$id, (int)$materiaId]);
                }
            }
            $pdo->commit();
            redirigirConExito('index.php', 'Alumno actualizado correctamente.');
        } catch (PDOException $e) {
            $pdo->rollBack();
            $error = $e->getCode() == 23000
                ? 'Ya existe un alumno con esa matrícula.'
                : 'Error al guardar: ' . $e->getMessage();
        }
    }
    // conservar los datos escritos si hubo error
    $alumno = array_merge($alumno, compact('matricula', 'nombre', 'turno', 'especialidad', 'grupo', 'telefono', 'tutor'));
}

$materiasDisponibles = $pdo->query("SELECT id, nombre, grupo, especialidad FROM materias WHERE activo = 1 ORDER BY nombre")->fetchAll();
$stmtIns = $pdo->prepare("SELECT materia_id FROM inscripciones WHERE alumno_id = ?");
$stmtIns->execute([$id]);
$materiasAsignadas = array_column($stmtIns->fetchAll(), 'materia_id');

$tituloPagina = 'Editar alumno';
require __DIR__ . '/../includes/header.php';
?>

<h3 class="titulo-seccion">Editar alumno</h3>

<?php if ($error): ?>
  <div class="alert alert-danger"><i class="fa-solid fa-triangle-exclamation"></i> <?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<div class="card">
  <div class="card-body">
    <form method="POST">
      <input type="hidden" name="id" value="<?= $alumno['id'] ?>">
      <div class="row g-3">
        <div class="col-md-4">
          <label class="form-label">Matrícula</label>
          <input type="text" name="matricula" class="form-control" value="<?= htmlspecialchars($alumno['matricula'] ?? '') ?>">
        </div>
        <div class="col-md-8">
          <label class="form-label">Nombre completo *</label>
          <input type="text" name="nombre" class="form-control" required value="<?= htmlspecialchars($alumno['nombre']) ?>">
        </div>
        <div class="col-md-3">
          <label class="form-label">Turno *</label>
          <select name="turno" class="form-select" required>
            <option value="Matutino" <?= $alumno['turno'] === 'Matutino' ? 'selected' : '' ?>>Matutino</option>
            <option value="Vespertino" <?= $alumno['turno'] === 'Vespertino' ? 'selected' : '' ?>>Vespertino</option>
          </select>
        </div>
        <div class="col-md-5">
          <label class="form-label">Especialidad *</label>
          <input type="text" name="especialidad" class="form-control" required value="<?= htmlspecialchars($alumno['especialidad']) ?>">
        </div>
        <div class="col-md-4">
          <label class="form-label">Grupo *</label>
          <input type="text" name="grupo" class="form-control" required value="<?= htmlspecialchars($alumno['grupo']) ?>">
        </div>
        <div class="col-md-6">
          <label class="form-label">Teléfono</label>
          <input type="text" name="telefono" class="form-control" value="<?= htmlspecialchars($alumno['telefono'] ?? '') ?>">
        </div>
        <div class="col-md-6">
          <label class="form-label">Tutor / Padre o madre</label>
          <input type="text" name="tutor" class="form-control" value="<?= htmlspecialchars($alumno['tutor'] ?? '') ?>">
        </div>
        <div class="col-12">
          <label class="form-label">Materias que cursa</label>
          <div class="border rounded p-3" style="max-height:220px; overflow-y:auto;">
            <?php foreach ($materiasDisponibles as $m): ?>
              <div class="form-check">
                <input class="form-check-input" type="checkbox" name="materias[]" value="<?= $m['id'] ?>" id="mat<?= $m['id'] ?>"
                  <?= in_array($m['id'], $materiasAsignadas) ? 'checked' : '' ?>>
                <label class="form-check-label" for="mat<?= $m['id'] ?>">
                  <?= htmlspecialchars($m['nombre']) ?> <small class="text-muted">(<?= htmlspecialchars($m['grupo']) ?> · <?= htmlspecialchars($m['especialidad']) ?>)</small>
                </label>
              </div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>
      <div class="mt-4 d-flex gap-2">
        <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Guardar cambios</button>
        <a href="index.php" class="btn btn-outline-secondary">Cancelar</a>
      </div>
    </form>
  </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
