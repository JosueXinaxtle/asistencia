<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/funciones.php';
requerirLogin();

$pdo = conectarDB();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $matricula   = limpiar($_POST['matricula'] ?? '');
    $nombre      = limpiar($_POST['nombre'] ?? '');
    $turno       = limpiar($_POST['turno'] ?? '');
    $especialidad = limpiar($_POST['especialidad'] ?? '');
    $grupo       = limpiar($_POST['grupo'] ?? '');
    $telefono    = limpiar($_POST['telefono'] ?? '');
    $tutor       = limpiar($_POST['tutor'] ?? '');
    $materias    = $_POST['materias'] ?? [];

    if ($nombre === '' || $turno === '' || $especialidad === '' || $grupo === '') {
        $error = 'Completa los campos obligatorios: nombre, turno, especialidad y grupo.';
    } else {
        try {
            $pdo->beginTransaction();
            $stmt = $pdo->prepare("INSERT INTO alumnos (matricula, nombre, turno, especialidad, grupo, telefono, tutor)
                                    VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$matricula ?: null, $nombre, $turno, $especialidad, $grupo, $telefono, $tutor]);
            $alumnoId = $pdo->lastInsertId();

            if (!empty($materias)) {
                $stmtIns = $pdo->prepare("INSERT IGNORE INTO inscripciones (alumno_id, materia_id) VALUES (?, ?)");
                foreach ($materias as $materiaId) {
                    $stmtIns->execute([$alumnoId, (int)$materiaId]);
                }
            }
            $pdo->commit();
            redirigirConExito('index.php', 'Alumno agregado correctamente.');
        } catch (PDOException $e) {
            $pdo->rollBack();
            $error = $e->getCode() == 23000
                ? 'Ya existe un alumno con esa matrícula.'
                : 'Error al guardar: ' . $e->getMessage();
        }
    }
}

$materiasDisponibles = $pdo->query("SELECT id, nombre, grupo, especialidad FROM materias WHERE activo = 1 ORDER BY nombre")->fetchAll();

$tituloPagina = 'Agregar alumno';
require __DIR__ . '/../includes/header.php';
?>

<h3 class="titulo-seccion">Agregar alumno</h3>

<?php if ($error): ?>
  <div class="alert alert-danger"><i class="fa-solid fa-triangle-exclamation"></i> <?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<div class="card">
  <div class="card-body">
    <form method="POST">
      <div class="row g-3">
        <div class="col-md-4">
          <label class="form-label">Matrícula</label>
          <input type="text" name="matricula" class="form-control" value="<?= htmlspecialchars($_POST['matricula'] ?? '') ?>">
        </div>
        <div class="col-md-8">
          <label class="form-label">Nombre completo *</label>
          <input type="text" name="nombre" class="form-control" required value="<?= htmlspecialchars($_POST['nombre'] ?? '') ?>">
        </div>
        <div class="col-md-3">
          <label class="form-label">Turno *</label>
          <select name="turno" class="form-select" required>
            <option value="">Selecciona...</option>
            <option value="Matutino" <?= ($_POST['turno'] ?? '') === 'Matutino' ? 'selected' : '' ?>>Matutino</option>
            <option value="Vespertino" <?= ($_POST['turno'] ?? '') === 'Vespertino' ? 'selected' : '' ?>>Vespertino</option>
          </select>
        </div>
        <div class="col-md-5">
          <label class="form-label">Especialidad *</label>
          <input type="text" name="especialidad" class="form-control" required value="<?= htmlspecialchars($_POST['especialidad'] ?? '') ?>" placeholder="Ej: Informática">
        </div>
        <div class="col-md-4">
          <label class="form-label">Grupo *</label>
          <input type="text" name="grupo" class="form-control" required value="<?= htmlspecialchars($_POST['grupo'] ?? '') ?>" placeholder="Ej: 3A">
        </div>
        <div class="col-md-6">
          <label class="form-label">Teléfono</label>
          <input type="text" name="telefono" class="form-control" value="<?= htmlspecialchars($_POST['telefono'] ?? '') ?>">
        </div>
        <div class="col-md-6">
          <label class="form-label">Tutor / Padre o madre</label>
          <input type="text" name="tutor" class="form-control" value="<?= htmlspecialchars($_POST['tutor'] ?? '') ?>">
        </div>
        <div class="col-12">
          <label class="form-label">Materias que cursa</label>
          <div class="border rounded p-3" style="max-height:220px; overflow-y:auto;">
            <?php if (!$materiasDisponibles): ?>
              <p class="text-muted mb-0">No hay materias registradas aún. <a href="../materias/agregar.php">Agregar una materia</a>.</p>
            <?php endif; ?>
            <?php foreach ($materiasDisponibles as $m): ?>
              <div class="form-check">
                <input class="form-check-input" type="checkbox" name="materias[]" value="<?= $m['id'] ?>" id="mat<?= $m['id'] ?>">
                <label class="form-check-label" for="mat<?= $m['id'] ?>">
                  <?= htmlspecialchars($m['nombre']) ?> <small class="text-muted">(<?= htmlspecialchars($m['grupo']) ?> · <?= htmlspecialchars($m['especialidad']) ?>)</small>
                </label>
              </div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>
      <div class="mt-4 d-flex gap-2">
        <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Guardar alumno</button>
        <a href="index.php" class="btn btn-outline-secondary">Cancelar</a>
      </div>
    </form>
  </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
