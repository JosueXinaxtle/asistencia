<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/funciones.php';
requerirLogin();

$pdo = conectarDB();
$termino = trim($_GET['q'] ?? '');
echo filaAlumnosHTML($pdo, $termino);
