// Confirmación genérica antes de eliminar un registro
document.addEventListener('click', function (e) {
  const btn = e.target.closest('.btn-eliminar');
  if (!btn) return;
  const nombre = btn.dataset.nombre || 'este registro';
  if (!confirm('¿Seguro que deseas eliminar "' + nombre + '"? Esta acción no se puede deshacer.')) {
    e.preventDefault();
  }
});

// Buscador dinámico de alumnos (AJAX)
const inputBuscador = document.getElementById('buscadorAlumnos');
if (inputBuscador) {
  const cuerpoTabla = document.getElementById('cuerpoTablaAlumnos');
  const base = inputBuscador.dataset.base || '';
  let temporizador = null;

  inputBuscador.addEventListener('keyup', function () {
    clearTimeout(temporizador);
    const termino = this.value.trim();
    temporizador = setTimeout(() => buscarAlumnos(termino), 300);
  });

  function buscarAlumnos(termino) {
    fetch(base + 'alumnos/buscar_ajax.php?q=' + encodeURIComponent(termino))
      .then(res => res.text())
      .then(html => { cuerpoTabla.innerHTML = html; })
      .catch(() => {
        cuerpoTabla.innerHTML = '<tr><td colspan="7" class="text-center text-danger py-3">Error al buscar. Intenta de nuevo.</td></tr>';
      });
  }
}

// Marcar todos los alumnos con un mismo estado de asistencia
function marcarTodos(estado) {
  document.querySelectorAll('.select-estado').forEach(sel => { sel.value = estado; });
}
