<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/funciones.php';
requerirLogin();

$pdo = conectarDB();
$materiaId = (int)($_GET['materia_id'] ?? 0);
$fecha = $_GET['fecha'] ?? date('Y-m-d');

$stmt = $pdo->prepare("SELECT * FROM materias WHERE id = ?");
$stmt->execute([$materiaId]);
$materia = $stmt->fetch();

if (!$materia) {
    redirigirConError('tomar.php', 'Materia no encontrada.');
}

$stmt = $pdo->prepare("
  SELECT al.matricula, al.nombre, a.estado
  FROM asistencias a
  JOIN alumnos al ON al.id = a.alumno_id
  WHERE a.materia_id = ? AND a.fecha = ?
  ORDER BY al.nombre
");
$stmt->execute([$materiaId, $fecha]);
$registros = $stmt->fetchAll();

$conteo = ['Asistencia' => 0, 'Falta' => 0, 'Retardo' => 0, 'Justificado' => 0];
foreach ($registros as $r) {
    $conteo[$r['estado']]++;
}
$total = count($registros);

$tituloPagina = 'Resultado de asistencia';
require __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3 no-print">
  <h3 class="titulo-seccion mb-0">Resultado de asistencia</h3>
  <div class="d-flex gap-2">
    <button onclick="window.print()" class="btn btn-outline-primary"><i class="fa-solid fa-print"></i> Imprimir</button>
    <a href="tomar.php?materia_id=<?= $materiaId ?>&fecha=<?= urlencode($fecha) ?>" class="btn btn-outline-secondary"><i class="fa-solid fa-pen"></i> Corregir</a>
  </div>
</div>

<div class="alert alert-success no-print"><i class="fa-solid fa-circle-check"></i> La asistencia se guardó correctamente.</div>

<div class="boleta">
  <div class="boleta-encabezado">
    <h2><?= htmlspecialchars(NOMBRE_PLANTEL) ?></h2>
    <p class="mb-0">Reporte de asistencia diaria</p>
  </div>

  <div class="row mb-3">
    <div class="col-md-6"><strong>Materia:</strong> <?= htmlspecialchars($materia['nombre']) ?></div>
    <div class="col-md-3"><strong>Grupo:</strong> <?= htmlspecialchars($materia['grupo']) ?></div>
    <div class="col-md-3"><strong>Fecha:</strong> <?= date('d/m/Y', strtotime($fecha)) ?></div>
  </div>

  <div class="row g-3 mb-4">
    <div class="col-6 col-md-3">
      <div class="card kpi-card p-3">
        <div class="kpi-etiqueta">Asistencias</div>
        <div class="kpi-numero text-success"><?= $conteo['Asistencia'] ?></div>
      </div>
    </div>
    <div class="col-6 col-md-3">
      <div class="card kpi-card p-3">
        <div class="kpi-etiqueta">Faltas</div>
        <div class="kpi-numero text-danger"><?= $conteo['Falta'] ?></div>
      </div>
    </div>
    <div class="col-6 col-md-3">
      <div class="card kpi-card p-3">
        <div class="kpi-etiqueta">Retardos</div>
        <div class="kpi-numero" style="color:#c78a00;"><?= $conteo['Retardo'] ?></div>
      </div>
    </div>
    <div class="col-6 col-md-3">
      <div class="card kpi-card p-3">
        <div class="kpi-etiqueta">Justificados</div>
        <div class="kpi-numero" style="color:#2c5b8a;"><?= $conteo['Justificado'] ?></div>
      </div>
    </div>
  </div>

  <table class="table table-bordered">
    <thead>
      <tr><th>Matrícula</th><th>Alumno</th><th>Estado</th></tr>
    </thead>
    <tbody>
      <?php foreach ($registros as $r): ?>
      <tr>
        <td><?= htmlspecialchars($r['matricula'] ?: '—') ?></td>
        <td><?= htmlspecialchars($r['nombre']) ?></td>
        <td><span class="estado-badge estado-<?= $r['estado'] ?>"><?= $r['estado'] ?></span></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <p class="text-end text-muted mt-3 mb-0" style="font-size:.85rem;">
    Total de registros: <?= $total ?> · Generado el <?= date('d/m/Y H:i') ?>
  </p>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
