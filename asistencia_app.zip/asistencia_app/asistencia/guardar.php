<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/funciones.php';
requerirLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: tomar.php');
    exit;
}

$pdo = conectarDB();
$materiaId = (int)($_POST['materia_id'] ?? 0);
$fecha = $_POST['fecha'] ?? date('Y-m-d');
$estados = $_POST['estados'] ?? [];

if (!$materiaId || !$estados) {
    redirigirConError('tomar.php', 'No se recibió información de asistencia para guardar.');
}

$stmt = $pdo->prepare("
  INSERT INTO asistencias (alumno_id, materia_id, fecha, estado, registrado_por)
  VALUES (?, ?, ?, ?, ?)
  ON DUPLICATE KEY UPDATE estado = VALUES(estado), registrado_por = VALUES(registrado_por)
");

foreach ($estados as $alumnoId => $estado) {
    $estadosValidos = ['Asistencia', 'Falta', 'Retardo', 'Justificado'];
    if (!in_array($estado, $estadosValidos, true)) continue;
    $stmt->execute([(int)$alumnoId, $materiaId, $fecha, $estado, $_SESSION['usuario_id']]);
}

header('Location: resultado.php?materia_id=' . $materiaId . '&fecha=' . urlencode($fecha));
exit;
