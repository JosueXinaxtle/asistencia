<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/funciones.php';
requerirLogin();

$pdo = conectarDB();

$sqlMaterias = "SELECT id, nombre, grupo FROM materias WHERE activo = 1";
$paramsM = [];
if (!esAdmin()) {
    $sqlMaterias .= " AND profesor_id = (SELECT id FROM profesores WHERE usuario_id = ?)";
    $paramsM[] = $_SESSION['usuario_id'];
}
$stmt = $pdo->prepare($sqlMaterias . " ORDER BY nombre");
$stmt->execute($paramsM);
$materias = $stmt->fetchAll();

$materiaId = (int)($_GET['materia_id'] ?? 0);
$desde = $_GET['desde'] ?? date('Y-m-01');
$hasta = $_GET['hasta'] ?? date('Y-m-d');
$alumnoTexto = trim($_GET['alumno'] ?? '');

$registros = [];
if ($materiaId) {
    $sql = "
      SELECT a.fecha, a.estado, al.matricula, al.nombre
      FROM asistencias a
      JOIN alumnos al ON al.id = a.alumno_id
      WHERE a.materia_id = ? AND a.fecha BETWEEN ? AND ?
    ";
    $params = [$materiaId, $desde, $hasta];
    if ($alumnoTexto !== '') {
        $sql .= " AND al.nombre LIKE ? ";
        $params[] = "%$alumnoTexto%";
    }
    $sql .= " ORDER BY a.fecha DESC, al.nombre";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $registros = $stmt->fetchAll();
}

$tituloPagina = 'Historial de asistencias';
require __DIR__ . '/../includes/header.php';
?>

<h3 class="titulo-seccion">Historial de asistencias</h3>
<?php mostrarMensaje(); ?>

<div class="card mb-3">
  <div class="card-body">
    <form method="GET" class="row g-3 align-items-end">
      <div class="col-md-4">
        <label class="form-label">Materia</label>
        <select name="materia_id" class="form-select" required>
          <option value="">Selecciona...</option>
          <?php foreach ($materias as $m): ?>
            <option value="<?= $m['id'] ?>" <?= $materiaId == $m['id'] ? 'selected' : '' ?>><?= htmlspecialchars($m['nombre']) ?> (<?= htmlspecialchars($m['grupo']) ?>)</option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-2">
        <label class="form-label">Desde</label>
        <input type="date" name="desde" class="form-control" value="<?= htmlspecialchars($desde) ?>">
      </div>
      <div class="col-md-2">
        <label class="form-label">Hasta</label>
        <input type="date" name="hasta" class="form-control" value="<?= htmlspecialchars($hasta) ?>">
      </div>
      <div class="col-md-3">
        <label class="form-label">Alumno (opcional)</label>
        <input type="text" name="alumno" class="form-control" placeholder="Buscar por nombre..." value="<?= htmlspecialchars($alumnoTexto) ?>">
      </div>
      <div class="col-md-1">
        <button type="submit" class="btn btn-primary w-100"><i class="fa-solid fa-filter"></i></button>
      </div>
    </form>
  </div>
</div>

<?php if ($materiaId): ?>
<div class="card">
  <div class="table-responsive">
    <table class="table table-hover mb-0">
      <thead>
        <tr><th>Fecha</th><th>Matrícula</th><th>Alumno</th><th>Estado</th></tr>
      </thead>
      <tbody>
        <?php if (!$registros): ?>
          <tr><td colspan="4" class="text-center text-muted py-4">No hay registros en el rango seleccionado.</td></tr>
        <?php endif; ?>
        <?php foreach ($registros as $r): ?>
        <tr>
          <td><?= date('d/m/Y', strtotime($r['fecha'])) ?></td>
          <td><?= htmlspecialchars($r['matricula'] ?: '—') ?></td>
          <td><?= htmlspecialchars($r['nombre']) ?></td>
          <td><span class="estado-badge estado-<?= $r['estado'] ?>"><?= $r['estado'] ?></span></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php else: ?>
  <div class="alert alert-info">Selecciona una materia y un rango de fechas para ver el historial.</div>
<?php endif; ?>

<?php require __DIR__ . '/../includes/footer.php'; ?>
