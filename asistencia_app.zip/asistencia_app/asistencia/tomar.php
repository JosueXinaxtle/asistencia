<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/funciones.php';
requerirLogin();

$pdo = conectarDB();

// Si el usuario es profesor, solo ve sus propias materias
$sqlMaterias = "SELECT m.id, m.nombre, m.grupo, m.especialidad FROM materias m WHERE m.activo = 1";
$params = [];
if (!esAdmin()) {
    $sqlMaterias .= " AND m.profesor_id = (SELECT id FROM profesores WHERE usuario_id = ?)";
    $params[] = $_SESSION['usuario_id'];
}
$sqlMaterias .= " ORDER BY m.nombre";
$stmt = $pdo->prepare($sqlMaterias);
$stmt->execute($params);
$materias = $stmt->fetchAll();

$materiaId = (int)($_GET['materia_id'] ?? 0);
$fecha = $_GET['fecha'] ?? date('Y-m-d');
$alumnos = [];
$materiaSeleccionada = null;

if ($materiaId) {
    $stmt = $pdo->prepare("SELECT * FROM materias WHERE id = ?");
    $stmt->execute([$materiaId]);
    $materiaSeleccionada = $stmt->fetch();

    if ($materiaSeleccionada) {
        $stmt = $pdo->prepare("
          SELECT al.id, al.matricula, al.nombre,
                 a.estado AS estado_actual
          FROM alumnos al
          JOIN inscripciones i ON i.alumno_id = al.id
          LEFT JOIN asistencias a ON a.alumno_id = al.id AND a.materia_id = ? AND a.fecha = ?
          WHERE i.materia_id = ? AND al.activo = 1
          ORDER BY al.nombre
        ");
        $stmt->execute([$materiaId, $fecha, $materiaId]);
        $alumnos = $stmt->fetchAll();
    }
}

$tituloPagina = 'Tomar asistencia';
require __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-2">
  <h3 class="titulo-seccion mb-0">Tomar asistencia</h3>
  <a href="historial.php" class="btn btn-outline-secondary btn-sm"><i class="fa-solid fa-clock-rotate-left"></i> Ver historial</a>
</div>
<?php mostrarMensaje(); ?>

<div class="card mb-3">
  <div class="card-body">
    <form method="GET" class="row g-3 align-items-end">
      <div class="col-md-6">
        <label class="form-label">Materia</label>
        <select name="materia_id" class="form-select" required onchange="this.form.submit()">
          <option value="">Selecciona una materia...</option>
          <?php foreach ($materias as $m): ?>
            <option value="<?= $m['id'] ?>" <?= $materiaId == $m['id'] ? 'selected' : '' ?>>
              <?= htmlspecialchars($m['nombre']) ?> — <?= htmlspecialchars($m['grupo']) ?> (<?= htmlspecialchars($m['especialidad']) ?>)
            </option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-4">
        <label class="form-label">Fecha</label>
        <input type="date" name="fecha" class="form-control" value="<?= htmlspecialchars($fecha) ?>" onchange="this.form.submit()">
      </div>
      <div class="col-md-2">
        <button type="submit" class="btn btn-outline-primary w-100"><i class="fa-solid fa-magnifying-glass"></i> Cargar</button>
      </div>
    </form>
  </div>
</div>

<?php if ($materiaId && !$materiaSeleccionada): ?>
  <div class="alert alert-warning">No se encontró la materia seleccionada o no tienes permiso para tomarle asistencia.</div>
<?php elseif ($materiaSeleccionada): ?>

  <?php if (!$alumnos): ?>
    <div class="alert alert-info">Esta materia aún no tiene alumnos inscritos. Ve a <a href="../alumnos/index.php">Alumnos</a> para inscribirlos.</div>
  <?php else: ?>

  <form method="POST" action="guardar.php">
    <input type="hidden" name="materia_id" value="<?= $materiaId ?>">
    <input type="hidden" name="fecha" value="<?= htmlspecialchars($fecha) ?>">

    <div class="card">
      <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
        <span><i class="fa-solid fa-book"></i> <?= htmlspecialchars($materiaSeleccionada['nombre']) ?> · Grupo <?= htmlspecialchars($materiaSeleccionada['grupo']) ?> · <?= date('d/m/Y', strtotime($fecha)) ?></span>
        <div class="btn-group btn-group-sm">
          <button type="button" class="btn btn-outline-success" onclick="marcarTodos('Asistencia')">Marcar todos: Asistencia</button>
          <button type="button" class="btn btn-outline-danger" onclick="marcarTodos('Falta')">Marcar todos: Falta</button>
        </div>
      </div>
      <div class="table-responsive">
        <table class="table table-hover mb-0">
          <thead>
            <tr>
              <th>Matrícula</th>
              <th>Alumno</th>
              <th style="width:220px;">Estado</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($alumnos as $a): ?>
            <tr>
              <td><?= htmlspecialchars($a['matricula'] ?: '—') ?></td>
              <td><?= htmlspecialchars($a['nombre']) ?></td>
              <td>
                <select name="estados[<?= $a['id'] ?>]" class="form-select form-select-sm select-estado">
                  <?php $actual = $a['estado_actual'] ?: 'Asistencia'; ?>
                  <option value="Asistencia" <?= $actual === 'Asistencia' ? 'selected' : '' ?>>Asistencia</option>
                  <option value="Falta" <?= $actual === 'Falta' ? 'selected' : '' ?>>Falta</option>
                  <option value="Retardo" <?= $actual === 'Retardo' ? 'selected' : '' ?>>Retardo</option>
                  <option value="Justificado" <?= $actual === 'Justificado' ? 'selected' : '' ?>>Justificado</option>
                </select>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>

    <div class="mt-3">
      <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Guardar asistencia</button>
    </div>
  </form>

  <?php endif; ?>
<?php endif; ?>

<?php require __DIR__ . '/../includes/footer.php'; ?>
