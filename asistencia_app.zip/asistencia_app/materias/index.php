<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/funciones.php';
requerirLogin();

$pdo = conectarDB();
$materias = $pdo->query("
  SELECT m.*, p.nombre AS profesor_nombre,
         (SELECT COUNT(*) FROM inscripciones i WHERE i.materia_id = m.id) AS total_alumnos
  FROM materias m
  LEFT JOIN profesores p ON p.id = m.profesor_id
  WHERE m.activo = 1
  ORDER BY m.nombre
")->fetchAll();

$tituloPagina = 'Materias';
require __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
  <h3 class="titulo-seccion mb-0">Materias</h3>
  <?php if (esAdmin()): ?>
  <a href="agregar.php" class="btn btn-primary"><i class="fa-solid fa-plus"></i> Agregar materia</a>
  <?php endif; ?>
</div>

<?php mostrarMensaje(); ?>

<div class="card">
  <div class="table-responsive">
    <table class="table table-hover mb-0">
      <thead>
        <tr>
          <th>Materia</th>
          <th>Profesor</th>
          <th>Grupo</th>
          <th>Especialidad</th>
          <th>Turno</th>
          <th>Alumnos inscritos</th>
          <?php if (esAdmin()): ?><th>Acciones</th><?php endif; ?>
        </tr>
      </thead>
      <tbody>
        <?php if (!$materias): ?>
          <tr><td colspan="7" class="text-center text-muted py-4">No hay materias registradas.</td></tr>
        <?php endif; ?>
        <?php foreach ($materias as $m): ?>
        <tr>
          <td><strong><?= htmlspecialchars($m['nombre']) ?></strong></td>
          <td><?= htmlspecialchars($m['profesor_nombre'] ?: 'Sin asignar') ?></td>
          <td><?= htmlspecialchars($m['grupo']) ?></td>
          <td><?= htmlspecialchars($m['especialidad']) ?></td>
          <td><?= htmlspecialchars($m['turno']) ?></td>
          <td><span class="badge bg-secondary"><?= $m['total_alumnos'] ?></span></td>
          <?php if (esAdmin()): ?>
          <td class="text-nowrap">
            <a href="editar.php?id=<?= $m['id'] ?>" class="btn btn-sm btn-outline-primary" title="Editar"><i class="fa-solid fa-pen"></i></a>
            <a href="eliminar.php?id=<?= $m['id'] ?>" class="btn btn-sm btn-outline-danger btn-eliminar" data-nombre="<?= htmlspecialchars($m['nombre']) ?>" title="Eliminar"><i class="fa-solid fa-trash"></i></a>
          </td>
          <?php endif; ?>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
