<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/funciones.php';
requerirAdmin();

$pdo = conectarDB();
$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);

$stmt = $pdo->prepare("SELECT * FROM materias WHERE id = ?");
$stmt->execute([$id]);
$materia = $stmt->fetch();

if (!$materia) {
    redirigirConError('index.php', 'Materia no encontrada.');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre       = limpiar($_POST['nombre'] ?? '');
    $profesorId   = (int)($_POST['profesor_id'] ?? 0) ?: null;
    $grupo        = limpiar($_POST['grupo'] ?? '');
    $especialidad = limpiar($_POST['especialidad'] ?? '');
    $turno        = limpiar($_POST['turno'] ?? '');

    if ($nombre === '' || $grupo === '' || $especialidad === '' || $turno === '') {
        $error = 'Completa todos los campos obligatorios.';
    } else {
        $stmt = $pdo->prepare("UPDATE materias SET nombre=?, profesor_id=?, grupo=?, especialidad=?, turno=? WHERE id=?");
        $stmt->execute([$nombre, $profesorId, $grupo, $especialidad, $turno, $id]);
        redirigirConExito('index.php', 'Materia actualizada correctamente.');
    }
    $materia = array_merge($materia, compact('nombre', 'grupo', 'especialidad', 'turno'));
    $materia['profesor_id'] = $profesorId;
}

$profesores = $pdo->query("SELECT id, nombre FROM profesores WHERE activo = 1 ORDER BY nombre")->fetchAll();

$tituloPagina = 'Editar materia';
require __DIR__ . '/../includes/header.php';
?>

<h3 class="titulo-seccion">Editar materia</h3>

<?php if ($error): ?>
  <div class="alert alert-danger"><i class="fa-solid fa-triangle-exclamation"></i> <?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<div class="card">
  <div class="card-body">
    <form method="POST">
      <input type="hidden" name="id" value="<?= $materia['id'] ?>">
      <div class="row g-3">
        <div class="col-md-6">
          <label class="form-label">Nombre de la materia *</label>
          <input type="text" name="nombre" class="form-control" required value="<?= htmlspecialchars($materia['nombre']) ?>">
        </div>
        <div class="col-md-6">
          <label class="form-label">Profesor</label>
          <select name="profesor_id" class="form-select">
            <option value="">Sin asignar</option>
            <?php foreach ($profesores as $p): ?>
              <option value="<?= $p['id'] ?>" <?= $materia['profesor_id'] == $p['id'] ? 'selected' : '' ?>><?= htmlspecialchars($p['nombre']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-4">
          <label class="form-label">Grupo *</label>
          <input type="text" name="grupo" class="form-control" required value="<?= htmlspecialchars($materia['grupo']) ?>">
        </div>
        <div class="col-md-4">
          <label class="form-label">Especialidad *</label>
          <input type="text" name="especialidad" class="form-control" required value="<?= htmlspecialchars($materia['especialidad']) ?>">
        </div>
        <div class="col-md-4">
          <label class="form-label">Turno *</label>
          <select name="turno" class="form-select" required>
            <option value="Matutino" <?= $materia['turno'] === 'Matutino' ? 'selected' : '' ?>>Matutino</option>
            <option value="Vespertino" <?= $materia['turno'] === 'Vespertino' ? 'selected' : '' ?>>Vespertino</option>
          </select>
        </div>
      </div>
      <div class="mt-4 d-flex gap-2">
        <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Guardar cambios</button>
        <a href="index.php" class="btn btn-outline-secondary">Cancelar</a>
      </div>
    </form>
  </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
