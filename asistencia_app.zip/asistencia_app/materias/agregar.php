<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/funciones.php';
requerirAdmin();

$pdo = conectarDB();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre       = limpiar($_POST['nombre'] ?? '');
    $profesorId   = (int)($_POST['profesor_id'] ?? 0) ?: null;
    $grupo        = limpiar($_POST['grupo'] ?? '');
    $especialidad = limpiar($_POST['especialidad'] ?? '');
    $turno        = limpiar($_POST['turno'] ?? '');

    if ($nombre === '' || $grupo === '' || $especialidad === '' || $turno === '') {
        $error = 'Completa todos los campos obligatorios.';
    } else {
        $stmt = $pdo->prepare("INSERT INTO materias (nombre, profesor_id, grupo, especialidad, turno) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$nombre, $profesorId, $grupo, $especialidad, $turno]);
        redirigirConExito('index.php', 'Materia agregada correctamente.');
    }
}

$profesores = $pdo->query("SELECT id, nombre FROM profesores WHERE activo = 1 ORDER BY nombre")->fetchAll();

$tituloPagina = 'Agregar materia';
require __DIR__ . '/../includes/header.php';
?>

<h3 class="titulo-seccion">Agregar materia</h3>

<?php if ($error): ?>
  <div class="alert alert-danger"><i class="fa-solid fa-triangle-exclamation"></i> <?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<div class="card">
  <div class="card-body">
    <form method="POST">
      <div class="row g-3">
        <div class="col-md-6">
          <label class="form-label">Nombre de la materia *</label>
          <input type="text" name="nombre" class="form-control" required value="<?= htmlspecialchars($_POST['nombre'] ?? '') ?>">
        </div>
        <div class="col-md-6">
          <label class="form-label">Profesor</label>
          <select name="profesor_id" class="form-select">
            <option value="">Sin asignar</option>
            <?php foreach ($profesores as $p): ?>
              <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['nombre']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-4">
          <label class="form-label">Grupo *</label>
          <input type="text" name="grupo" class="form-control" required placeholder="Ej: 3A" value="<?= htmlspecialchars($_POST['grupo'] ?? '') ?>">
        </div>
        <div class="col-md-4">
          <label class="form-label">Especialidad *</label>
          <input type="text" name="especialidad" class="form-control" required value="<?= htmlspecialchars($_POST['especialidad'] ?? '') ?>">
        </div>
        <div class="col-md-4">
          <label class="form-label">Turno *</label>
          <select name="turno" class="form-select" required>
            <option value="">Selecciona...</option>
            <option value="Matutino">Matutino</option>
            <option value="Vespertino">Vespertino</option>
          </select>
        </div>
      </div>
      <div class="mt-4 d-flex gap-2">
        <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Guardar materia</button>
        <a href="index.php" class="btn btn-outline-secondary">Cancelar</a>
      </div>
    </form>
  </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
