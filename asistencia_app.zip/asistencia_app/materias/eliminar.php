<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/funciones.php';
requerirAdmin();

$pdo = conectarDB();
$id = (int)($_GET['id'] ?? 0);

try {
    $pdo->prepare("DELETE FROM materias WHERE id = ?")->execute([$id]);
    redirigirConExito('index.php', 'Materia eliminada correctamente.');
} catch (PDOException $e) {
    redirigirConError('index.php', 'No se pudo eliminar la materia.');
}
