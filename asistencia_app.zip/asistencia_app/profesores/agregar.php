<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/funciones.php';
requerirAdmin();

$pdo = conectarDB();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre       = limpiar($_POST['nombre'] ?? '');
    $especialidad = limpiar($_POST['especialidad'] ?? '');
    $telefono     = limpiar($_POST['telefono'] ?? '');
    $email        = limpiar($_POST['email'] ?? '');
    $crearCuenta  = isset($_POST['crear_cuenta']);
    $usuario      = limpiar($_POST['usuario'] ?? '');
    $password     = $_POST['password'] ?? '';

    if ($nombre === '') {
        $error = 'El nombre del profesor es obligatorio.';
    } elseif ($crearCuenta && ($usuario === '' || $password === '')) {
        $error = 'Para crear una cuenta de acceso, indica usuario y contraseña.';
    } else {
        try {
            $pdo->beginTransaction();
            $usuarioId = null;

            if ($crearCuenta) {
                $hash = password_hash($password, PASSWORD_BCRYPT);
                $stmtU = $pdo->prepare("INSERT INTO usuarios (nombre, usuario, password, rol) VALUES (?, ?, ?, 'profesor')");
                $stmtU->execute([$nombre, $usuario, $hash]);
                $usuarioId = $pdo->lastInsertId();
            }

            $stmt = $pdo->prepare("INSERT INTO profesores (usuario_id, nombre, especialidad, telefono, email) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$usuarioId, $nombre, $especialidad, $telefono, $email]);

            $pdo->commit();
            redirigirConExito('index.php', 'Profesor agregado correctamente.');
        } catch (PDOException $e) {
            $pdo->rollBack();
            $error = $e->getCode() == 23000
                ? 'El nombre de usuario ya está en uso.'
                : 'Error al guardar: ' . $e->getMessage();
        }
    }
}

$tituloPagina = 'Agregar profesor';
require __DIR__ . '/../includes/header.php';
?>

<h3 class="titulo-seccion">Agregar profesor</h3>

<?php if ($error): ?>
  <div class="alert alert-danger"><i class="fa-solid fa-triangle-exclamation"></i> <?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<div class="card">
  <div class="card-body">
    <form method="POST">
      <div class="row g-3">
        <div class="col-md-6">
          <label class="form-label">Nombre completo *</label>
          <input type="text" name="nombre" class="form-control" required value="<?= htmlspecialchars($_POST['nombre'] ?? '') ?>">
        </div>
        <div class="col-md-6">
          <label class="form-label">Especialidad</label>
          <input type="text" name="especialidad" class="form-control" value="<?= htmlspecialchars($_POST['especialidad'] ?? '') ?>">
        </div>
        <div class="col-md-6">
          <label class="form-label">Teléfono</label>
          <input type="text" name="telefono" class="form-control" value="<?= htmlspecialchars($_POST['telefono'] ?? '') ?>">
        </div>
        <div class="col-md-6">
          <label class="form-label">Email</label>
          <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
        </div>
      </div>

      <hr class="my-4">
      <div class="form-check form-switch mb-3">
        <input class="form-check-input" type="checkbox" role="switch" id="crearCuenta" name="crear_cuenta" onchange="document.getElementById('bloqueCuenta').classList.toggle('d-none', !this.checked)">
        <label class="form-check-label fw-semibold" for="crearCuenta">Crear cuenta de acceso al sistema para este profesor</label>
      </div>
      <div id="bloqueCuenta" class="row g-3 d-none">
        <div class="col-md-6">
          <label class="form-label">Usuario</label>
          <input type="text" name="usuario" class="form-control" value="<?= htmlspecialchars($_POST['usuario'] ?? '') ?>">
        </div>
        <div class="col-md-6">
          <label class="form-label">Contraseña</label>
          <input type="password" name="password" class="form-control">
        </div>
      </div>

      <div class="mt-4 d-flex gap-2">
        <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Guardar profesor</button>
        <a href="index.php" class="btn btn-outline-secondary">Cancelar</a>
      </div>
    </form>
  </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
