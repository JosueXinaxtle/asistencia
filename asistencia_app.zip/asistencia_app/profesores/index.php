<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/funciones.php';
requerirAdmin();

$pdo = conectarDB();
$profesores = $pdo->query("
  SELECT p.*, COUNT(DISTINCT m.id) AS total_materias
  FROM profesores p
  LEFT JOIN materias m ON m.profesor_id = p.id AND m.activo = 1
  WHERE p.activo = 1
  GROUP BY p.id
  ORDER BY p.nombre
")->fetchAll();

$tituloPagina = 'Profesores';
require __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
  <h3 class="titulo-seccion mb-0">Profesores</h3>
  <a href="agregar.php" class="btn btn-primary"><i class="fa-solid fa-user-plus"></i> Agregar profesor</a>
</div>

<?php mostrarMensaje(); ?>

<div class="card">
  <div class="table-responsive">
    <table class="table table-hover mb-0">
      <thead>
        <tr>
          <th>Nombre</th>
          <th>Especialidad</th>
          <th>Teléfono</th>
          <th>Email</th>
          <th>Materias asignadas</th>
          <th>Acciones</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!$profesores): ?>
          <tr><td colspan="6" class="text-center text-muted py-4">No hay profesores registrados.</td></tr>
        <?php endif; ?>
        <?php foreach ($profesores as $p): ?>
        <tr>
          <td><strong><?= htmlspecialchars($p['nombre']) ?></strong></td>
          <td><?= htmlspecialchars($p['especialidad'] ?: '—') ?></td>
          <td><?= htmlspecialchars($p['telefono'] ?: '—') ?></td>
          <td><?= htmlspecialchars($p['email'] ?: '—') ?></td>
          <td><span class="badge bg-secondary"><?= $p['total_materias'] ?></span></td>
          <td class="text-nowrap">
            <a href="editar.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-outline-primary" title="Editar"><i class="fa-solid fa-pen"></i></a>
            <a href="eliminar.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-outline-danger btn-eliminar" data-nombre="<?= htmlspecialchars($p['nombre']) ?>" title="Eliminar"><i class="fa-solid fa-trash"></i></a>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
