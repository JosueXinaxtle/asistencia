<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/funciones.php';
requerirAdmin();

$pdo = conectarDB();
$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);

$stmt = $pdo->prepare("SELECT * FROM profesores WHERE id = ?");
$stmt->execute([$id]);
$profesor = $stmt->fetch();

if (!$profesor) {
    redirigirConError('index.php', 'Profesor no encontrado.');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre       = limpiar($_POST['nombre'] ?? '');
    $especialidad = limpiar($_POST['especialidad'] ?? '');
    $telefono     = limpiar($_POST['telefono'] ?? '');
    $email        = limpiar($_POST['email'] ?? '');

    if ($nombre === '') {
        $error = 'El nombre del profesor es obligatorio.';
    } else {
        $stmt = $pdo->prepare("UPDATE profesores SET nombre=?, especialidad=?, telefono=?, email=? WHERE id=?");
        $stmt->execute([$nombre, $especialidad, $telefono, $email, $id]);

        // Si el profesor tiene cuenta de usuario, mantener el nombre sincronizado
        if ($profesor['usuario_id']) {
            $pdo->prepare("UPDATE usuarios SET nombre = ? WHERE id = ?")->execute([$nombre, $profesor['usuario_id']]);
        }

        redirigirConExito('index.php', 'Profesor actualizado correctamente.');
    }
    $profesor = array_merge($profesor, compact('nombre', 'especialidad', 'telefono', 'email'));
}

$tituloPagina = 'Editar profesor';
require __DIR__ . '/../includes/header.php';
?>

<h3 class="titulo-seccion">Editar profesor</h3>

<?php if ($error): ?>
  <div class="alert alert-danger"><i class="fa-solid fa-triangle-exclamation"></i> <?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<div class="card">
  <div class="card-body">
    <form method="POST">
      <input type="hidden" name="id" value="<?= $profesor['id'] ?>">
      <div class="row g-3">
        <div class="col-md-6">
          <label class="form-label">Nombre completo *</label>
          <input type="text" name="nombre" class="form-control" required value="<?= htmlspecialchars($profesor['nombre']) ?>">
        </div>
        <div class="col-md-6">
          <label class="form-label">Especialidad</label>
          <input type="text" name="especialidad" class="form-control" value="<?= htmlspecialchars($profesor['especialidad'] ?? '') ?>">
        </div>
        <div class="col-md-6">
          <label class="form-label">Teléfono</label>
          <input type="text" name="telefono" class="form-control" value="<?= htmlspecialchars($profesor['telefono'] ?? '') ?>">
        </div>
        <div class="col-md-6">
          <label class="form-label">Email</label>
          <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($profesor['email'] ?? '') ?>">
        </div>
      </div>
      <div class="mt-4 d-flex gap-2">
        <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Guardar cambios</button>
        <a href="index.php" class="btn btn-outline-secondary">Cancelar</a>
      </div>
    </form>
  </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
