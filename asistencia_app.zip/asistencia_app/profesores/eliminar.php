<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/funciones.php';
requerirAdmin();

$pdo = conectarDB();
$id = (int)($_GET['id'] ?? 0);

try {
    $stmt = $pdo->prepare("SELECT usuario_id FROM profesores WHERE id = ?");
    $stmt->execute([$id]);
    $prof = $stmt->fetch();

    $pdo->prepare("DELETE FROM profesores WHERE id = ?")->execute([$id]);

    // Elimina también la cuenta de usuario ligada, si existe
    if ($prof && $prof['usuario_id']) {
        $pdo->prepare("DELETE FROM usuarios WHERE id = ?")->execute([$prof['usuario_id']]);
    }

    redirigirConExito('index.php', 'Profesor eliminado correctamente.');
} catch (PDOException $e) {
    redirigirConError('index.php', 'No se pudo eliminar el profesor.');
}
