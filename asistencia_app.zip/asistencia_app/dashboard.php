<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/includes/funciones.php';
requerirLogin();

$pdo = conectarDB();

$totalAlumnos   = $pdo->query("SELECT COUNT(*) FROM alumnos WHERE activo = 1")->fetchColumn();
$totalMaterias  = $pdo->query("SELECT COUNT(*) FROM materias WHERE activo = 1")->fetchColumn();
$totalProfesores = $pdo->query("SELECT COUNT(*) FROM profesores WHERE activo = 1")->fetchColumn();
$asistenciasHoy = $pdo->prepare("SELECT COUNT(*) FROM asistencias WHERE fecha = CURDATE() AND estado = 'Asistencia'");
$asistenciasHoy->execute();
$asistenciasHoy = $asistenciasHoy->fetchColumn();

$faltasHoy = $pdo->prepare("SELECT COUNT(*) FROM asistencias WHERE fecha = CURDATE() AND estado = 'Falta'");
$faltasHoy->execute();
$faltasHoy = $faltasHoy->fetchColumn();

// Últimos registros de asistencia
$ultimos = $pdo->query("
  SELECT a.fecha, a.estado, al.nombre AS alumno, m.nombre AS materia
  FROM asistencias a
  JOIN alumnos al ON al.id = a.alumno_id
  JOIN materias m ON m.id = a.materia_id
  ORDER BY a.creado_en DESC
  LIMIT 8
")->fetchAll();

$tituloPagina = 'Panel Principal';
require __DIR__ . '/includes/header.php';
?>

<h3 class="titulo-seccion">Panel Principal</h3>
<?php mostrarMensaje(); ?>

<div class="row g-3 mb-4">
  <div class="col-6 col-md-3">
    <div class="card kpi-card p-3">
      <div class="kpi-etiqueta"><i class="fa-solid fa-user-graduate"></i> Alumnos</div>
      <div class="kpi-numero"><?= $totalAlumnos ?></div>
    </div>
  </div>
  <div class="col-6 col-md-3">
    <div class="card kpi-card p-3">
      <div class="kpi-etiqueta"><i class="fa-solid fa-book"></i> Materias</div>
      <div class="kpi-numero"><?= $totalMaterias ?></div>
    </div>
  </div>
  <div class="col-6 col-md-3">
    <div class="card kpi-card p-3">
      <div class="kpi-etiqueta"><i class="fa-solid fa-chalkboard-user"></i> Profesores</div>
      <div class="kpi-numero"><?= $totalProfesores ?></div>
    </div>
  </div>
  <div class="col-6 col-md-3">
    <div class="card kpi-card p-3">
      <div class="kpi-etiqueta"><i class="fa-solid fa-calendar-day"></i> Asistencias hoy</div>
      <div class="kpi-numero"><?= $asistenciasHoy ?> <small class="text-danger fs-6"><?= $faltasHoy ? "/ {$faltasHoy} faltas" : '' ?></small></div>
    </div>
  </div>
</div>

<div class="row g-3">
  <div class="col-lg-7">
    <div class="card">
      <div class="card-header"><i class="fa-solid fa-bolt"></i> Accesos rápidos</div>
      <div class="card-body d-flex flex-wrap gap-2">
        <a href="asistencia/tomar.php" class="btn btn-primary"><i class="fa-solid fa-clipboard-check"></i> Tomar asistencia</a>
        <a href="alumnos/agregar.php" class="btn btn-outline-primary"><i class="fa-solid fa-user-plus"></i> Nuevo alumno</a>
        <a href="boletas/index.php" class="btn btn-outline-primary"><i class="fa-solid fa-file-invoice"></i> Generar boleta</a>
        <a href="horarios/index.php" class="btn btn-outline-primary"><i class="fa-solid fa-calendar-days"></i> Ver horarios</a>
        <?php if (esAdmin()): ?>
        <a href="profesores/agregar.php" class="btn btn-outline-secondary"><i class="fa-solid fa-user-plus"></i> Nuevo profesor</a>
        <a href="materias/agregar.php" class="btn btn-outline-secondary"><i class="fa-solid fa-plus"></i> Nueva materia</a>
        <?php endif; ?>
      </div>
    </div>
  </div>
  <div class="col-lg-5">
    <div class="card">
      <div class="card-header"><i class="fa-solid fa-clock-rotate-left"></i> Últimos registros de asistencia</div>
      <ul class="list-group list-group-flush">
        <?php if (!$ultimos): ?>
          <li class="list-group-item text-muted">Aún no hay registros de asistencia.</li>
        <?php endif; ?>
        <?php foreach ($ultimos as $r): ?>
          <li class="list-group-item d-flex justify-content-between align-items-center">
            <div>
              <strong><?= htmlspecialchars($r['alumno']) ?></strong><br>
              <small class="text-muted"><?= htmlspecialchars($r['materia']) ?> · <?= date('d/m/Y', strtotime($r['fecha'])) ?></small>
            </div>
            <span class="estado-badge estado-<?= $r['estado'] ?>"><?= $r['estado'] ?></span>
          </li>
        <?php endforeach; ?>
      </ul>
    </div>
  </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
