<?php
/**
 * Configuración de conexión a la base de datos MySQL.
 * Ajusta estos valores según tu servidor (XAMPP, hosting, etc.)
 */
define('DB_HOST', 'localhost');
define('DB_NAME', 'asistencia_escolar');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// Nombre del plantel / institución (aparece en encabezados y boletas)
define('NOMBRE_PLANTEL', 'Mi Institución Educativa');

function conectarDB(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
        $opciones = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $opciones);
        } catch (PDOException $e) {
            die('Error de conexión a la base de datos: ' . $e->getMessage());
        }
    }
    return $pdo;
}
