<?php
require_once __DIR__ . '/session.php';
$base = rutaBase();
$paginaActual = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= isset($tituloPagina) ? htmlspecialchars($tituloPagina) . ' · ' : '' ?>Control de Asistencia</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= $base ?>assets/css/style.css">
</head>
<body>
<?php if (estaLogueado()): ?>
<nav class="navbar navbar-expand-lg navbar-institucional no-print">
  <div class="container-fluid px-4">
    <a class="navbar-brand" href="<?= $base ?>dashboard.php">
      <i class="fa-solid fa-graduation-cap"></i> <?= htmlspecialchars(NOMBRE_PLANTEL ?? 'Control de Asistencia') ?>
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navMenu">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link" href="<?= $base ?>dashboard.php"><i class="fa-solid fa-gauge"></i> Panel</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= $base ?>alumnos/index.php"><i class="fa-solid fa-user-graduate"></i> Alumnos</a></li>
        <?php if (esAdmin()): ?>
        <li class="nav-item"><a class="nav-link" href="<?= $base ?>profesores/index.php"><i class="fa-solid fa-chalkboard-user"></i> Profesores</a></li>
        <?php endif; ?>
        <li class="nav-item"><a class="nav-link" href="<?= $base ?>materias/index.php"><i class="fa-solid fa-book"></i> Materias</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= $base ?>asistencia/tomar.php"><i class="fa-solid fa-clipboard-check"></i> Asistencia</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= $base ?>calificaciones/capturar.php"><i class="fa-solid fa-marker"></i> Calificaciones</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= $base ?>horarios/index.php"><i class="fa-solid fa-calendar-days"></i> Horarios</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= $base ?>boletas/index.php"><i class="fa-solid fa-file-invoice"></i> Boletas</a></li>
        <?php if (esAdmin()): ?>
        <li class="nav-item"><a class="nav-link" href="<?= $base ?>periodos/index.php"><i class="fa-solid fa-calendar-week"></i> Periodos</a></li>
        <?php endif; ?>
      </ul>
      <ul class="navbar-nav">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
            <i class="fa-solid fa-circle-user"></i> <?= htmlspecialchars($_SESSION['nombre']) ?>
            <span class="badge-rol"><?= nombreRol($_SESSION['rol']) ?></span>
          </a>
          <ul class="dropdown-menu dropdown-menu-end">
            <li><a class="dropdown-item" href="<?= $base ?>logout.php"><i class="fa-solid fa-right-from-bracket"></i> Cerrar sesión</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>
<?php endif; ?>
<main class="contenedor-principal">
