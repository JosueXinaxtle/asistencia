<?php
/** Limpia texto de entrada */
function limpiar(string $valor): string
{
    return trim(htmlspecialchars($valor, ENT_QUOTES, 'UTF-8'));
}

/** Muestra una alerta Bootstrap si existe un parámetro de mensaje en la URL */
function mostrarMensaje(): void
{
    if (!empty($_GET['ok'])) {
        echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="fa-solid fa-circle-check"></i> ' . htmlspecialchars($_GET['ok']) . '
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
              </div>';
    }
    if (!empty($_GET['error'])) {
        $texto = $_GET['error'] === 'acceso'
            ? 'No tienes permisos para acceder a esa sección.'
            : $_GET['error'];
        echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="fa-solid fa-triangle-exclamation"></i> ' . htmlspecialchars($texto) . '
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
              </div>';
    }
}

/** Calcula el promedio de dos parciales (ignora nulos) */
function promedioParciales(?float $p1, ?float $p2): ?float
{
    $valores = array_filter([$p1, $p2], fn($v) => $v !== null);
    if (empty($valores)) return null;
    return round(array_sum($valores) / count($valores), 1);
}

/** Calcula el porcentaje de asistencia a partir de conteos */
function porcentajeAsistencia(int $asistencias, int $totalClases): float
{
    if ($totalClases === 0) return 0;
    return round(($asistencias / $totalClases) * 100, 1);
}

/** Redirige con un mensaje de éxito */
function redirigirConExito(string $url, string $mensaje): void
{
    header('Location: ' . $url . (str_contains($url, '?') ? '&' : '?') . 'ok=' . urlencode($mensaje));
    exit;
}

/** Redirige con un mensaje de error */
function redirigirConError(string $url, string $mensaje): void
{
    header('Location: ' . $url . (str_contains($url, '?') ? '&' : '?') . 'error=' . urlencode($mensaje));
    exit;
}

/**
 * Genera las filas <tr> de la tabla de alumnos, con materias y profesores
 * agrupados. Se usa tanto en el listado normal como en el buscador AJAX.
 */
function filaAlumnosHTML(PDO $pdo, string $termino = ''): string
{
    $sql = "
      SELECT al.id, al.matricula, al.nombre, al.turno, al.especialidad, al.grupo,
             GROUP_CONCAT(DISTINCT m.nombre ORDER BY m.nombre SEPARATOR ', ') AS materias,
             GROUP_CONCAT(DISTINCT p.nombre ORDER BY p.nombre SEPARATOR ', ') AS profesores
      FROM alumnos al
      LEFT JOIN inscripciones i ON i.alumno_id = al.id
      LEFT JOIN materias m ON m.id = i.materia_id
      LEFT JOIN profesores p ON p.id = m.profesor_id
      WHERE al.activo = 1
    ";
    $params = [];
    if ($termino !== '') {
        $sql .= " AND (al.nombre LIKE ? OR al.matricula LIKE ? OR al.grupo LIKE ? OR al.especialidad LIKE ?) ";
        $like = "%$termino%";
        $params = [$like, $like, $like, $like];
    }
    $sql .= " GROUP BY al.id ORDER BY al.nombre ASC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $alumnos = $stmt->fetchAll();

    if (!$alumnos) {
        return '<tr><td colspan="8" class="text-center text-muted py-4">No se encontraron alumnos.</td></tr>';
    }

    $html = '';
    foreach ($alumnos as $a) {
        $html .= '<tr>
            <td>' . htmlspecialchars($a['matricula'] ?: '—') . '</td>
            <td><strong>' . htmlspecialchars($a['nombre']) . '</strong></td>
            <td>' . htmlspecialchars($a['turno']) . '</td>
            <td>' . htmlspecialchars($a['especialidad']) . '</td>
            <td>' . htmlspecialchars($a['grupo']) . '</td>
            <td>' . htmlspecialchars($a['materias'] ?: '—') . '</td>
            <td>' . htmlspecialchars($a['profesores'] ?: '—') . '</td>
            <td class="text-nowrap">
              <a href="editar.php?id=' . $a['id'] . '" class="btn btn-sm btn-outline-primary" title="Editar"><i class="fa-solid fa-pen"></i></a>
              <a href="eliminar.php?id=' . $a['id'] . '" class="btn btn-sm btn-outline-danger btn-eliminar" data-nombre="' . htmlspecialchars($a['nombre']) . '" title="Eliminar"><i class="fa-solid fa-trash"></i></a>
            </td>
          </tr>';
    }
    return $html;
}
