<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/** ¿Hay un usuario con sesión iniciada? */
function estaLogueado(): bool
{
    return isset($_SESSION['usuario_id']);
}

/** ¿El usuario en sesión es administrador? */
function esAdmin(): bool
{
    return estaLogueado() && $_SESSION['rol'] === 'admin';
}

/** Obliga a tener sesión iniciada; si no, redirige al login */
function requerirLogin(): void
{
    if (!estaLogueado()) {
        header('Location: ' . rutaBase() . 'login.php');
        exit;
    }
}

/** Obliga a que el usuario sea administrador */
function requerirAdmin(): void
{
    requerirLogin();
    if (!esAdmin()) {
        header('Location: ' . rutaBase() . 'dashboard.php?error=acceso');
        exit;
    }
}

/**
 * Calcula la ruta relativa a la raíz del proyecto según la profundidad
 * de la carpeta actual, para que los enlaces funcionen desde cualquier
 * subcarpeta (alumnos/, profesores/, etc.)
 */
function rutaBase(): string
{
    $script = str_replace('\\', '/', $_SERVER['SCRIPT_NAME']);
    $partes = explode('/', trim($script, '/'));
    // Quita el nombre del archivo
    array_pop($partes);
    // Busca dónde está la carpeta raíz del proyecto (contiene index.php principal)
    // Estrategia simple: si el script está en una subcarpeta de primer nivel, sube un nivel.
    $enSubcarpeta = in_array(true, [
        strpos($script, '/alumnos/') !== false,
        strpos($script, '/profesores/') !== false,
        strpos($script, '/materias/') !== false,
        strpos($script, '/periodos/') !== false,
        strpos($script, '/asistencia/') !== false,
        strpos($script, '/horarios/') !== false,
        strpos($script, '/boletas/') !== false,
        strpos($script, '/calificaciones/') !== false,
    ], true);
    return $enSubcarpeta ? '../' : '';
}

/** Texto legible del rol */
function nombreRol(string $rol): string
{
    return $rol === 'admin' ? 'Administrador' : 'Profesor';
}
