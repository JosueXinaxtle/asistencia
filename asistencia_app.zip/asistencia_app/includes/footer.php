</main>
<?php if (estaLogueado()): ?>
<footer class="pie-pagina no-print">
  <div class="container-fluid px-4">
    <small>&copy; <?= date('Y') ?> <?= htmlspecialchars(NOMBRE_PLANTEL ?? '') ?> — Sistema de Control de Asistencia</small>
  </div>
</footer>
<?php endif; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= rutaBase() ?>assets/js/main.js"></script>
</body>
</html>
