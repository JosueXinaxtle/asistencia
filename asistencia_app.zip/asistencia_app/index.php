<?php
require_once __DIR__ . '/includes/session.php';
header('Location: ' . (estaLogueado() ? 'dashboard.php' : 'login.php'));
exit;
