# Sistema de Control de Asistencia Escolar

Aplicación web dinámica desarrollada en **HTML, CSS, PHP y MySQL** para el
registro y control de asistencia de alumnos, calificaciones y horarios de
clase, con sesión de usuarios (Administrador y Profesor).

## Características

- **Sesión de usuarios** con dos roles: `admin` (control total) y `profesor`
  (solo sus materias y grupos asignados).
- **Alumnos**: alta, baja, modificación y buscador dinámico (AJAX) que
  muestra nombre, turno, especialidad, grupo, materia(s) y profesor(es).
- **Profesores**: alta, baja y modificación, con opción de crear su cuenta
  de acceso al sistema.
- **Materias**: alta, baja y modificación, vinculadas a profesor, grupo,
  especialidad y turno.
- **Periodos escolares**: semestres de 6 meses, evaluados con 2 parciales.
- **Asistencia**: registro diario por materia, con resultado inmediato
  (conteo de asistencias/faltas/retardos/justificados) e impresión del
  reporte del día. Incluye historial con filtros por materia, alumno y
  rango de fechas.
- **Calificaciones**: captura de 2 parciales por materia y periodo.
- **Boletas**: búsqueda de alumno, generación de boleta semestral
  imprimible con calificaciones, promedio y porcentaje de asistencia
  por materia.
- **Horarios de clase**: subida (administrador) y descarga de archivos
  (PDF, imagen o Excel) por grupo, especialidad y turno.
- Diseño **serio e institucional** basado en Bootstrap 5, con paleta de
  colores propia y estilos de impresión para boletas y reportes.

## Requisitos

- PHP 8.0 o superior con extensión **PDO MySQL**.
- Servidor MySQL o MariaDB 5.7+.
- Servidor web (Apache, Nginx o el servidor embebido de PHP).
- Navegador moderno (Chrome, Firefox, Edge).

Funciona directamente en **XAMPP, WAMP, MAMP** o cualquier hosting con PHP
y MySQL.

## Instalación

1. **Descomprime** este proyecto dentro de la carpeta de tu servidor web
   (por ejemplo `htdocs/` en XAMPP o `www/` en WAMP).

2. **Crea la base de datos** importando el archivo `database/schema.sql`:
   - Desde phpMyAdmin: crea una nueva base de datos o simplemente importa
     el archivo (el script ya incluye `CREATE DATABASE`).
   - Desde la terminal:
     ```bash
     mysql -u root -p < database/schema.sql
     ```

3. **Configura la conexión** editando `config/database.php` con los datos
   de tu servidor MySQL:
   ```php
   define('DB_HOST', 'localhost');
   define('DB_NAME', 'asistencia_escolar');
   define('DB_USER', 'root');
   define('DB_PASS', '');
   ```
   También puedes cambiar el nombre de tu institución en
   `NOMBRE_PLANTEL`, que aparece en los encabezados y boletas.

4. **Da permisos de escritura** a la carpeta `uploads/` (para los horarios
   de clase que se suban):
   ```bash
   chmod -R 775 uploads/
   ```

5. **Abre la aplicación** en tu navegador, por ejemplo:
   `http://localhost/asistencia_app/`

## Acceso por defecto

| Usuario | Contraseña | Rol |
|---------|-----------|-----|
| `admin` | `admin123` | Administrador |

**Importante:** cambia esta contraseña o crea un nuevo usuario
administrador desde la base de datos antes de usar el sistema en
producción (puedes generar un nuevo hash con `password_hash()` en PHP).

## Flujo de uso recomendado

1. Inicia sesión como **admin**.
2. Ve a **Periodos** y crea el semestre actual (6 meses).
3. Ve a **Profesores** y da de alta a los docentes (opcionalmente con
   cuenta de acceso propia).
4. Ve a **Materias** y crea las materias, asignando profesor, grupo,
   especialidad y turno.
5. Ve a **Alumnos** y da de alta a los estudiantes, marcando las materias
   que cursan.
6. Desde **Asistencia → Tomar asistencia**, selecciona materia y fecha
   para pasar lista; al guardar se muestra el resultado y se puede
   imprimir.
7. Desde **Calificaciones**, captura los 2 parciales de cada materia.
8. Desde **Boletas**, busca al alumno, elige el periodo y genera/imprime
   su boleta semestral.
9. Desde **Horarios**, sube los horarios de clase en PDF/imagen/Excel
   para que los alumnos o profesores puedan descargarlos.

## Estructura del proyecto

```
asistencia_app/
├── config/           Conexión a la base de datos
├── includes/         Sesión, funciones y plantillas (header/footer)
├── assets/           CSS y JavaScript
├── database/         Script SQL de instalación
├── alumnos/          CRUD y buscador de alumnos
├── profesores/       CRUD de profesores
├── materias/         CRUD de materias
├── periodos/         Gestión de semestres
├── asistencia/       Toma de asistencia, resultados e historial
├── calificaciones/   Captura de parciales
├── boletas/          Generación e impresión de boletas
├── horarios/         Subida y descarga de horarios de clase
└── uploads/          Archivos subidos (horarios)
```

## Seguridad

- Las contraseñas se almacenan con `password_hash()` (bcrypt).
- Todas las consultas usan sentencias preparadas (PDO) contra inyección SQL.
- La carpeta `uploads/` bloquea la ejecución de scripts mediante `.htaccess`.
- El acceso a cada módulo se valida por sesión y rol en el servidor.

## Personalización

- Cambia el nombre del plantel y los datos de conexión en
  `config/database.php`.
- Ajusta colores y tipografía en `assets/css/style.css`
  (variables al inicio del archivo, sección `:root`).
