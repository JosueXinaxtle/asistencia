-- =========================================================
-- Sistema de Control de Asistencia Escolar
-- Base de datos: asistencia_escolar
-- =========================================================

CREATE DATABASE IF NOT EXISTS asistencia_escolar
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE asistencia_escolar;

-- ---------------------------------------------------------
-- Usuarios del sistema (administradores y profesores)
-- ---------------------------------------------------------
CREATE TABLE usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(150) NOT NULL,
  usuario VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  rol ENUM('admin','profesor') NOT NULL DEFAULT 'profesor',
  activo TINYINT(1) NOT NULL DEFAULT 1,
  creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Profesores
-- ---------------------------------------------------------
CREATE TABLE profesores (
  id INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT NULL,
  nombre VARCHAR(150) NOT NULL,
  especialidad VARCHAR(120),
  telefono VARCHAR(30),
  email VARCHAR(120),
  activo TINYINT(1) NOT NULL DEFAULT 1,
  creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Periodos escolares (semestres de 6 meses, con 2 parciales)
-- ---------------------------------------------------------
CREATE TABLE periodos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,          -- Ej: "Semestre Ago 2026 - Ene 2027"
  fecha_inicio DATE NOT NULL,
  fecha_fin DATE NOT NULL,
  activo TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Materias
-- ---------------------------------------------------------
CREATE TABLE materias (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(150) NOT NULL,
  profesor_id INT NULL,
  grupo VARCHAR(20) NOT NULL,
  especialidad VARCHAR(120) NOT NULL,
  turno ENUM('Matutino','Vespertino') NOT NULL DEFAULT 'Matutino',
  activo TINYINT(1) NOT NULL DEFAULT 1,
  FOREIGN KEY (profesor_id) REFERENCES profesores(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Alumnos
-- ---------------------------------------------------------
CREATE TABLE alumnos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  matricula VARCHAR(30) UNIQUE,
  nombre VARCHAR(150) NOT NULL,
  turno ENUM('Matutino','Vespertino') NOT NULL,
  especialidad VARCHAR(120) NOT NULL,
  grupo VARCHAR(20) NOT NULL,
  telefono VARCHAR(30),
  tutor VARCHAR(150),
  activo TINYINT(1) NOT NULL DEFAULT 1,
  creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Relación Materia <-> Alumno (inscripciones)
-- ---------------------------------------------------------
CREATE TABLE inscripciones (
  id INT AUTO_INCREMENT PRIMARY KEY,
  alumno_id INT NOT NULL,
  materia_id INT NOT NULL,
  UNIQUE KEY unico_insc (alumno_id, materia_id),
  FOREIGN KEY (alumno_id) REFERENCES alumnos(id) ON DELETE CASCADE,
  FOREIGN KEY (materia_id) REFERENCES materias(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Asistencias (registro diario por materia)
-- ---------------------------------------------------------
CREATE TABLE asistencias (
  id INT AUTO_INCREMENT PRIMARY KEY,
  alumno_id INT NOT NULL,
  materia_id INT NOT NULL,
  fecha DATE NOT NULL,
  estado ENUM('Asistencia','Falta','Retardo','Justificado') NOT NULL,
  registrado_por INT NULL,
  creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY unico_dia (alumno_id, materia_id, fecha),
  FOREIGN KEY (alumno_id) REFERENCES alumnos(id) ON DELETE CASCADE,
  FOREIGN KEY (materia_id) REFERENCES materias(id) ON DELETE CASCADE,
  FOREIGN KEY (registrado_por) REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Calificaciones (2 parciales por periodo/materia/alumno)
-- ---------------------------------------------------------
CREATE TABLE calificaciones (
  id INT AUTO_INCREMENT PRIMARY KEY,
  alumno_id INT NOT NULL,
  materia_id INT NOT NULL,
  periodo_id INT NOT NULL,
  parcial1 DECIMAL(4,1) NULL,
  parcial2 DECIMAL(4,1) NULL,
  UNIQUE KEY unico_calif (alumno_id, materia_id, periodo_id),
  FOREIGN KEY (alumno_id) REFERENCES alumnos(id) ON DELETE CASCADE,
  FOREIGN KEY (materia_id) REFERENCES materias(id) ON DELETE CASCADE,
  FOREIGN KEY (periodo_id) REFERENCES periodos(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Horarios de clase (archivos descargables por grupo/periodo)
-- ---------------------------------------------------------
CREATE TABLE horarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  grupo VARCHAR(20) NOT NULL,
  especialidad VARCHAR(120) NOT NULL,
  turno ENUM('Matutino','Vespertino') NOT NULL,
  periodo_id INT NULL,
  nombre_archivo VARCHAR(255) NOT NULL,
  ruta_archivo VARCHAR(255) NOT NULL,
  subido_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (periodo_id) REFERENCES periodos(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- =========================================================
-- Datos iniciales
-- =========================================================

-- Usuario administrador por defecto
-- usuario: admin   /   contraseña: admin123
INSERT INTO usuarios (nombre, usuario, password, rol) VALUES
('Administrador del Sistema', 'admin', '$2y$10$pH3ByGt2Q5mB7oSrOFIayeCSjjH4RxhTP.C5IEe.S9JqrsQbcHyYi', 'admin');

-- Periodo de ejemplo (6 meses)
INSERT INTO periodos (nombre, fecha_inicio, fecha_fin, activo) VALUES
('Semestre Ago 2026 - Ene 2027', '2026-08-01', '2027-01-31', 1);
