<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/funciones.php';
requerirLogin();

$pdo = conectarDB();

$termino = trim($_GET['q'] ?? '');
$sql = "SELECT id, matricula, nombre, grupo, especialidad FROM alumnos WHERE activo = 1";
$params = [];
if ($termino !== '') {
    $sql .= " AND (nombre LIKE ? OR matricula LIKE ?)";
    $params = ["%$termino%", "%$termino%"];
}
$sql .= " ORDER BY nombre LIMIT 50";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$alumnos = $stmt->fetchAll();

$periodos = $pdo->query("SELECT id, nombre FROM periodos ORDER BY fecha_inicio DESC")->fetchAll();

$tituloPagina = 'Boletas de calificaciones';
require __DIR__ . '/../includes/header.php';
?>

<h3 class="titulo-seccion">Boletas de calificaciones</h3>
<p class="text-muted">Genera e imprime la boleta semestral de un alumno (6 meses, 2 parciales por materia).</p>
<?php mostrarMensaje(); ?>

<div class="card mb-3">
  <div class="card-body">
    <form method="GET" class="row g-2">
      <div class="col-md-10">
        <input type="text" name="q" class="form-control" placeholder="Buscar alumno por nombre o matrícula..." value="<?= htmlspecialchars($termino) ?>">
      </div>
      <div class="col-md-2">
        <button type="submit" class="btn btn-outline-primary w-100"><i class="fa-solid fa-magnifying-glass"></i> Buscar</button>
      </div>
    </form>
  </div>
</div>

<div class="card">
  <div class="table-responsive">
    <table class="table table-hover mb-0">
      <thead>
        <tr><th>Matrícula</th><th>Alumno</th><th>Grupo</th><th>Especialidad</th><th>Periodo</th><th>Boleta</th></tr>
      </thead>
      <tbody>
        <?php if (!$alumnos): ?>
          <tr><td colspan="6" class="text-center text-muted py-4">No se encontraron alumnos.</td></tr>
        <?php endif; ?>
        <?php foreach ($alumnos as $a): ?>
        <tr>
          <td><?= htmlspecialchars($a['matricula'] ?: '—') ?></td>
          <td><strong><?= htmlspecialchars($a['nombre']) ?></strong></td>
          <td><?= htmlspecialchars($a['grupo']) ?></td>
          <td><?= htmlspecialchars($a['especialidad']) ?></td>
          <td>
            <form method="GET" action="generar.php" class="d-flex gap-2">
              <input type="hidden" name="alumno_id" value="<?= $a['id'] ?>">
              <select name="periodo_id" class="form-select form-select-sm" required>
                <?php foreach ($periodos as $p): ?>
                  <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['nombre']) ?></option>
                <?php endforeach; ?>
              </select>
          </td>
          <td>
              <button type="submit" class="btn btn-sm btn-primary"><i class="fa-solid fa-file-invoice"></i> Ver boleta</button>
            </form>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
