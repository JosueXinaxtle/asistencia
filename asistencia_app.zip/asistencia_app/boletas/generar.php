<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/funciones.php';
requerirLogin();

$pdo = conectarDB();
$alumnoId = (int)($_GET['alumno_id'] ?? 0);
$periodoId = (int)($_GET['periodo_id'] ?? 0);

$stmt = $pdo->prepare("SELECT * FROM alumnos WHERE id = ?");
$stmt->execute([$alumnoId]);
$alumno = $stmt->fetch();

$stmt = $pdo->prepare("SELECT * FROM periodos WHERE id = ?");
$stmt->execute([$periodoId]);
$periodo = $stmt->fetch();

if (!$alumno || !$periodo) {
    redirigirConError('index.php', 'Alumno o periodo no válido.');
}

// Materias del alumno con calificaciones del periodo
$stmt = $pdo->prepare("
  SELECT m.id AS materia_id, m.nombre AS materia, p.nombre AS profesor,
         c.parcial1, c.parcial2
  FROM inscripciones i
  JOIN materias m ON m.id = i.materia_id
  LEFT JOIN profesores p ON p.id = m.profesor_id
  LEFT JOIN calificaciones c ON c.alumno_id = i.alumno_id AND c.materia_id = m.id AND c.periodo_id = ?
  WHERE i.alumno_id = ?
  ORDER BY m.nombre
");
$stmt->execute([$periodoId, $alumnoId]);
$materias = $stmt->fetchAll();

// Asistencia por materia dentro del rango del periodo
$stmtAsis = $pdo->prepare("
  SELECT
    COUNT(*) AS total,
    SUM(CASE WHEN estado IN ('Asistencia','Retardo','Justificado') THEN 1 ELSE 0 END) AS presentes
  FROM asistencias
  WHERE alumno_id = ? AND materia_id = ? AND fecha BETWEEN ? AND ?
");

$sumaPromedios = 0;
$materiasConCalif = 0;

$tituloPagina = 'Boleta de calificaciones';
require __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3 no-print">
  <h3 class="titulo-seccion mb-0">Boleta de calificaciones</h3>
  <div class="d-flex gap-2">
    <button onclick="window.print()" class="btn btn-primary"><i class="fa-solid fa-print"></i> Imprimir boleta</button>
    <a href="index.php" class="btn btn-outline-secondary">Volver</a>
  </div>
</div>

<div class="boleta">
  <div class="boleta-encabezado">
    <h2><?= htmlspecialchars(NOMBRE_PLANTEL) ?></h2>
    <p class="mb-0">Boleta de calificaciones — <?= htmlspecialchars($periodo['nombre']) ?></p>
  </div>

  <div class="row mb-4">
    <div class="col-md-3"><strong>Matrícula:</strong> <?= htmlspecialchars($alumno['matricula'] ?: '—') ?></div>
    <div class="col-md-5"><strong>Alumno:</strong> <?= htmlspecialchars($alumno['nombre']) ?></div>
    <div class="col-md-2"><strong>Grupo:</strong> <?= htmlspecialchars($alumno['grupo']) ?></div>
    <div class="col-md-2"><strong>Turno:</strong> <?= htmlspecialchars($alumno['turno']) ?></div>
    <div class="col-md-12 mt-2"><strong>Especialidad:</strong> <?= htmlspecialchars($alumno['especialidad']) ?></div>
  </div>

  <table class="table table-bordered">
    <thead>
      <tr>
        <th>Materia</th>
        <th>Profesor</th>
        <th>Parcial 1</th>
        <th>Parcial 2</th>
        <th>Promedio</th>
        <th>% Asistencia</th>
      </tr>
    </thead>
    <tbody>
      <?php if (!$materias): ?>
        <tr><td colspan="6" class="text-center text-muted py-3">Este alumno no tiene materias asignadas.</td></tr>
      <?php endif; ?>
      <?php foreach ($materias as $m):
          $promedio = promedioParciales($m['parcial1'], $m['parcial2']);
          if ($promedio !== null) { $sumaPromedios += $promedio; $materiasConCalif++; }

          $stmtAsis->execute([$alumnoId, $m['materia_id'], $periodo['fecha_inicio'], $periodo['fecha_fin']]);
          $asis = $stmtAsis->fetch();
          $pct = porcentajeAsistencia((int)($asis['presentes'] ?? 0), (int)($asis['total'] ?? 0));
      ?>
      <tr>
        <td><?= htmlspecialchars($m['materia']) ?></td>
        <td><?= htmlspecialchars($m['profesor'] ?: '—') ?></td>
        <td class="text-center"><?= $m['parcial1'] !== null ? number_format($m['parcial1'], 1) : '—' ?></td>
        <td class="text-center"><?= $m['parcial2'] !== null ? number_format($m['parcial2'], 1) : '—' ?></td>
        <td class="text-center"><strong><?= $promedio !== null ? number_format($promedio, 1) : '—' ?></strong></td>
        <td class="text-center"><?= $asis['total'] > 0 ? $pct . '%' : 'Sin registro' ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
    <?php if ($materiasConCalif > 0): ?>
    <tfoot>
      <tr class="table-light">
        <td colspan="4" class="text-end"><strong>Promedio general del periodo:</strong></td>
        <td class="text-center"><strong><?= number_format($sumaPromedios / $materiasConCalif, 1) ?></strong></td>
        <td></td>
      </tr>
    </tfoot>
    <?php endif; ?>
  </table>

  <div class="row mt-5 pt-4">
    <div class="col-md-6 text-center">
      <div style="border-top:1px solid #333; width:80%; margin:0 auto;">Firma del padre / tutor</div>
    </div>
    <div class="col-md-6 text-center">
      <div style="border-top:1px solid #333; width:80%; margin:0 auto;">Firma del director / administrador</div>
    </div>
  </div>

  <p class="text-end text-muted mt-4 mb-0" style="font-size:.8rem;">
    Documento generado el <?= date('d/m/Y H:i') ?> · Periodo: <?= date('d/m/Y', strtotime($periodo['fecha_inicio'])) ?> — <?= date('d/m/Y', strtotime($periodo['fecha_fin'])) ?>
  </p>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
