<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/funciones.php';
requerirAdmin();

$pdo = conectarDB();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = limpiar($_POST['nombre'] ?? '');
    $inicio = $_POST['fecha_inicio'] ?? '';
    $fin    = $_POST['fecha_fin'] ?? '';

    if ($nombre === '' || !$inicio || !$fin) {
        $error = 'Completa todos los campos.';
    } elseif (strtotime($fin) <= strtotime($inicio)) {
        $error = 'La fecha fin debe ser posterior a la fecha inicio.';
    } else {
        $stmt = $pdo->prepare("INSERT INTO periodos (nombre, fecha_inicio, fecha_fin) VALUES (?, ?, ?)");
        $stmt->execute([$nombre, $inicio, $fin]);
        redirigirConExito('index.php', 'Periodo agregado correctamente.');
    }
}

$tituloPagina = 'Agregar periodo';
require __DIR__ . '/../includes/header.php';
?>

<h3 class="titulo-seccion">Agregar periodo escolar</h3>

<?php if ($error): ?>
  <div class="alert alert-danger"><i class="fa-solid fa-triangle-exclamation"></i> <?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<div class="card">
  <div class="card-body">
    <form method="POST">
      <div class="row g-3">
        <div class="col-md-12">
          <label class="form-label">Nombre del periodo *</label>
          <input type="text" name="nombre" class="form-control" required placeholder="Ej: Semestre Ago 2026 - Ene 2027" value="<?= htmlspecialchars($_POST['nombre'] ?? '') ?>">
        </div>
        <div class="col-md-6">
          <label class="form-label">Fecha de inicio *</label>
          <input type="date" name="fecha_inicio" class="form-control" required value="<?= htmlspecialchars($_POST['fecha_inicio'] ?? '') ?>">
        </div>
        <div class="col-md-6">
          <label class="form-label">Fecha de fin *</label>
          <input type="date" name="fecha_fin" class="form-control" required value="<?= htmlspecialchars($_POST['fecha_fin'] ?? '') ?>">
        </div>
      </div>
      <p class="text-muted mt-3 mb-0"><i class="fa-solid fa-circle-info"></i> Recuerda que cada periodo se evalúa con 2 parciales, capturados desde el módulo de Boletas.</p>
      <div class="mt-4 d-flex gap-2">
        <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Guardar periodo</button>
        <a href="index.php" class="btn btn-outline-secondary">Cancelar</a>
      </div>
    </form>
  </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
