<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/funciones.php';
requerirAdmin();

$pdo = conectarDB();
$periodos = $pdo->query("SELECT * FROM periodos ORDER BY fecha_inicio DESC")->fetchAll();

$tituloPagina = 'Periodos escolares';
require __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
  <h3 class="titulo-seccion mb-0">Periodos escolares (semestres)</h3>
  <a href="agregar.php" class="btn btn-primary"><i class="fa-solid fa-plus"></i> Agregar periodo</a>
</div>
<p class="text-muted">Cada periodo representa un semestre de 6 meses, evaluado con <strong>2 parciales</strong>. Las boletas se generan por periodo.</p>

<?php mostrarMensaje(); ?>

<div class="card">
  <div class="table-responsive">
    <table class="table table-hover mb-0">
      <thead>
        <tr>
          <th>Periodo</th>
          <th>Fecha inicio</th>
          <th>Fecha fin</th>
          <th>Estado</th>
          <th>Acciones</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!$periodos): ?>
          <tr><td colspan="5" class="text-center text-muted py-4">No hay periodos registrados.</td></tr>
        <?php endif; ?>
        <?php foreach ($periodos as $p): ?>
        <tr>
          <td><strong><?= htmlspecialchars($p['nombre']) ?></strong></td>
          <td><?= date('d/m/Y', strtotime($p['fecha_inicio'])) ?></td>
          <td><?= date('d/m/Y', strtotime($p['fecha_fin'])) ?></td>
          <td><?= $p['activo'] ? '<span class="badge bg-success">Activo</span>' : '<span class="badge bg-secondary">Cerrado</span>' ?></td>
          <td class="text-nowrap">
            <a href="eliminar.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-outline-danger btn-eliminar" data-nombre="<?= htmlspecialchars($p['nombre']) ?>" title="Eliminar"><i class="fa-solid fa-trash"></i></a>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
