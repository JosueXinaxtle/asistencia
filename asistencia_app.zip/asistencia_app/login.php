<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/session.php';

if (estaLogueado()) {
    header('Location: dashboard.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = trim($_POST['usuario'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($usuario === '' || $password === '') {
        $error = 'Ingresa usuario y contraseña.';
    } else {
        $pdo = conectarDB();
        $stmt = $pdo->prepare('SELECT * FROM usuarios WHERE usuario = ? AND activo = 1 LIMIT 1');
        $stmt->execute([$usuario]);
        $u = $stmt->fetch();

        if ($u && password_verify($password, $u['password'])) {
            session_regenerate_id(true);
            $_SESSION['usuario_id'] = $u['id'];
            $_SESSION['nombre']     = $u['nombre'];
            $_SESSION['rol']        = $u['rol'];
            header('Location: dashboard.php');
            exit;
        } else {
            $error = 'Usuario o contraseña incorrectos.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Iniciar sesión · Control de Asistencia</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="pantalla-login">
  <div class="tarjeta-login">
    <div class="icono-login"><i class="fa-solid fa-graduation-cap"></i></div>
    <h4 class="text-center mb-1" style="color:var(--azul-institucional); font-weight:700;">Control de Asistencia</h4>
    <p class="text-center text-muted mb-4" style="font-size:.9rem;">Inicia sesión para continuar</p>

    <?php if ($error): ?>
      <div class="alert alert-danger py-2"><i class="fa-solid fa-triangle-exclamation"></i> <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" novalidate>
      <div class="mb-3">
        <label class="form-label">Usuario</label>
        <input type="text" name="usuario" class="form-control" required autofocus value="<?= htmlspecialchars($_POST['usuario'] ?? '') ?>">
      </div>
      <div class="mb-3">
        <label class="form-label">Contraseña</label>
        <input type="password" name="password" class="form-control" required>
      </div>
      <button type="submit" class="btn btn-primary w-100 py-2 mt-2">
        <i class="fa-solid fa-right-to-bracket"></i> Entrar
      </button>
    </form>
    <p class="text-center text-muted mt-4 mb-0" style="font-size:.78rem;">
      Acceso para administradores y profesores
    </p>
  </div>
</div>
</body>
</html>
