<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/funciones.php';
requerirLogin();

$pdo = conectarDB();

$sqlMaterias = "SELECT id, nombre, grupo FROM materias WHERE activo = 1";
$paramsM = [];
if (!esAdmin()) {
    $sqlMaterias .= " AND profesor_id = (SELECT id FROM profesores WHERE usuario_id = ?)";
    $paramsM[] = $_SESSION['usuario_id'];
}
$stmt = $pdo->prepare($sqlMaterias . " ORDER BY nombre");
$stmt->execute($paramsM);
$materias = $stmt->fetchAll();

$periodos = $pdo->query("SELECT id, nombre FROM periodos ORDER BY fecha_inicio DESC")->fetchAll();

$materiaId = (int)($_GET['materia_id'] ?? 0);
$periodoId = (int)($_GET['periodo_id'] ?? ($periodos[0]['id'] ?? 0));
$alumnos = [];

if ($materiaId && $periodoId) {
    $stmt = $pdo->prepare("
      SELECT al.id, al.matricula, al.nombre, c.parcial1, c.parcial2
      FROM alumnos al
      JOIN inscripciones i ON i.alumno_id = al.id
      LEFT JOIN calificaciones c ON c.alumno_id = al.id AND c.materia_id = ? AND c.periodo_id = ?
      WHERE i.materia_id = ? AND al.activo = 1
      ORDER BY al.nombre
    ");
    $stmt->execute([$materiaId, $periodoId, $materiaId]);
    $alumnos = $stmt->fetchAll();
}

$tituloPagina = 'Captura de calificaciones';
require __DIR__ . '/../includes/header.php';
?>

<h3 class="titulo-seccion">Captura de calificaciones</h3>
<?php mostrarMensaje(); ?>

<div class="card mb-3">
  <div class="card-body">
    <form method="GET" class="row g-3 align-items-end">
      <div class="col-md-5">
        <label class="form-label">Materia</label>
        <select name="materia_id" class="form-select" required onchange="this.form.submit()">
          <option value="">Selecciona...</option>
          <?php foreach ($materias as $m): ?>
            <option value="<?= $m['id'] ?>" <?= $materiaId == $m['id'] ? 'selected' : '' ?>><?= htmlspecialchars($m['nombre']) ?> (<?= htmlspecialchars($m['grupo']) ?>)</option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-5">
        <label class="form-label">Periodo (semestre)</label>
        <select name="periodo_id" class="form-select" required onchange="this.form.submit()">
          <option value="">Selecciona...</option>
          <?php foreach ($periodos as $p): ?>
            <option value="<?= $p['id'] ?>" <?= $periodoId == $p['id'] ? 'selected' : '' ?>><?= htmlspecialchars($p['nombre']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-2">
        <button type="submit" class="btn btn-outline-primary w-100"><i class="fa-solid fa-magnifying-glass"></i> Cargar</button>
      </div>
    </form>
  </div>
</div>

<?php if ($materiaId && $periodoId): ?>
  <?php if (!$alumnos): ?>
    <div class="alert alert-info">Esta materia no tiene alumnos inscritos.</div>
  <?php else: ?>
  <form method="POST" action="guardar.php">
    <input type="hidden" name="materia_id" value="<?= $materiaId ?>">
    <input type="hidden" name="periodo_id" value="<?= $periodoId ?>">
    <div class="card">
      <div class="card-header">Calificaciones — 2 parciales (escala 0 a 10)</div>
      <div class="table-responsive">
        <table class="table mb-0">
          <thead>
            <tr><th>Matrícula</th><th>Alumno</th><th style="width:130px;">Parcial 1</th><th style="width:130px;">Parcial 2</th></tr>
          </thead>
          <tbody>
            <?php foreach ($alumnos as $a): ?>
            <tr>
              <td><?= htmlspecialchars($a['matricula'] ?: '—') ?></td>
              <td><?= htmlspecialchars($a['nombre']) ?></td>
              <td><input type="number" step="0.1" min="0" max="10" name="parcial1[<?= $a['id'] ?>]" class="form-control form-control-sm" value="<?= htmlspecialchars($a['parcial1'] ?? '') ?>"></td>
              <td><input type="number" step="0.1" min="0" max="10" name="parcial2[<?= $a['id'] ?>]" class="form-control form-control-sm" value="<?= htmlspecialchars($a['parcial2'] ?? '') ?>"></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
    <div class="mt-3">
      <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Guardar calificaciones</button>
    </div>
  </form>
  <?php endif; ?>
<?php endif; ?>

<?php require __DIR__ . '/../includes/footer.php'; ?>
