<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/funciones.php';
requerirLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: capturar.php');
    exit;
}

$pdo = conectarDB();
$materiaId = (int)($_POST['materia_id'] ?? 0);
$periodoId = (int)($_POST['periodo_id'] ?? 0);
$parcial1 = $_POST['parcial1'] ?? [];
$parcial2 = $_POST['parcial2'] ?? [];

if (!$materiaId || !$periodoId) {
    redirigirConError('capturar.php', 'Faltan datos de materia o periodo.');
}

$stmt = $pdo->prepare("
  INSERT INTO calificaciones (alumno_id, materia_id, periodo_id, parcial1, parcial2)
  VALUES (?, ?, ?, ?, ?)
  ON DUPLICATE KEY UPDATE parcial1 = VALUES(parcial1), parcial2 = VALUES(parcial2)
");

$alumnoIds = array_unique(array_merge(array_keys($parcial1), array_keys($parcial2)));
foreach ($alumnoIds as $alumnoId) {
    $p1 = $parcial1[$alumnoId] !== '' ? (float)$parcial1[$alumnoId] : null;
    $p2 = $parcial2[$alumnoId] !== '' ? (float)$parcial2[$alumnoId] : null;
    $stmt->execute([(int)$alumnoId, $materiaId, $periodoId, $p1, $p2]);
}

redirigirConExito("capturar.php?materia_id=$materiaId&periodo_id=$periodoId", 'Calificaciones guardadas correctamente.');
