<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/session.php';
requerirLogin();

$pdo = conectarDB();
$id = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare("SELECT * FROM horarios WHERE id = ?");
$stmt->execute([$id]);
$horario = $stmt->fetch();

if (!$horario) {
    header('Location: index.php?error=' . urlencode('Horario no encontrado.'));
    exit;
}

$rutaCompleta = __DIR__ . '/../uploads/horarios/' . $horario['ruta_archivo'];

if (!file_exists($rutaCompleta)) {
    header('Location: index.php?error=' . urlencode('El archivo ya no existe en el servidor.'));
    exit;
}

header('Content-Description: File Transfer');
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . $horario['nombre_archivo'] . '"');
header('Content-Length: ' . filesize($rutaCompleta));
readfile($rutaCompleta);
exit;
