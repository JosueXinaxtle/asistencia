<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/funciones.php';
requerirAdmin();

$pdo = conectarDB();
$error = '';

$extensionesPermitidas = ['pdf', 'jpg', 'jpeg', 'png', 'xlsx', 'xls'];
$carpetaDestino = __DIR__ . '/../uploads/horarios/';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $grupo        = limpiar($_POST['grupo'] ?? '');
    $especialidad = limpiar($_POST['especialidad'] ?? '');
    $turno        = limpiar($_POST['turno'] ?? '');
    $periodoId    = (int)($_POST['periodo_id'] ?? 0) ?: null;

    if ($grupo === '' || $especialidad === '' || $turno === '') {
        $error = 'Completa grupo, especialidad y turno.';
    } elseif (empty($_FILES['archivo']) || $_FILES['archivo']['error'] !== UPLOAD_ERR_OK) {
        $error = 'Selecciona un archivo válido para subir.';
    } else {
        $extension = strtolower(pathinfo($_FILES['archivo']['name'], PATHINFO_EXTENSION));
        if (!in_array($extension, $extensionesPermitidas, true)) {
            $error = 'Formato no permitido. Usa PDF, imagen (JPG/PNG) o Excel.';
        } elseif ($_FILES['archivo']['size'] > 10 * 1024 * 1024) {
            $error = 'El archivo no debe superar los 10 MB.';
        } else {
            $nombreOriginal = basename($_FILES['archivo']['name']);
            $nombreArchivo = 'horario_' . uniqid() . '.' . $extension;

            if (!is_dir($carpetaDestino)) mkdir($carpetaDestino, 0775, true);

            if (move_uploaded_file($_FILES['archivo']['tmp_name'], $carpetaDestino . $nombreArchivo)) {
                $stmt = $pdo->prepare("INSERT INTO horarios (grupo, especialidad, turno, periodo_id, nombre_archivo, ruta_archivo) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->execute([$grupo, $especialidad, $turno, $periodoId, $nombreOriginal, $nombreArchivo]);
                redirigirConExito('index.php', 'Horario subido correctamente.');
            } else {
                $error = 'No se pudo guardar el archivo en el servidor.';
            }
        }
    }
}

$periodos = $pdo->query("SELECT id, nombre FROM periodos ORDER BY fecha_inicio DESC")->fetchAll();

$tituloPagina = 'Subir horario';
require __DIR__ . '/../includes/header.php';
?>

<h3 class="titulo-seccion">Subir horario de clase</h3>

<?php if ($error): ?>
  <div class="alert alert-danger"><i class="fa-solid fa-triangle-exclamation"></i> <?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<div class="card">
  <div class="card-body">
    <form method="POST" enctype="multipart/form-data">
      <div class="row g-3">
        <div class="col-md-4">
          <label class="form-label">Grupo *</label>
          <input type="text" name="grupo" class="form-control" required placeholder="Ej: 3A" value="<?= htmlspecialchars($_POST['grupo'] ?? '') ?>">
        </div>
        <div class="col-md-4">
          <label class="form-label">Especialidad *</label>
          <input type="text" name="especialidad" class="form-control" required value="<?= htmlspecialchars($_POST['especialidad'] ?? '') ?>">
        </div>
        <div class="col-md-4">
          <label class="form-label">Turno *</label>
          <select name="turno" class="form-select" required>
            <option value="">Selecciona...</option>
            <option value="Matutino">Matutino</option>
            <option value="Vespertino">Vespertino</option>
          </select>
        </div>
        <div class="col-md-6">
          <label class="form-label">Periodo</label>
          <select name="periodo_id" class="form-select">
            <option value="">Sin especificar</option>
            <?php foreach ($periodos as $p): ?>
              <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['nombre']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-6">
          <label class="form-label">Archivo (PDF, imagen o Excel) *</label>
          <input type="file" name="archivo" class="form-control" required accept=".pdf,.jpg,.jpeg,.png,.xlsx,.xls">
        </div>
      </div>
      <div class="mt-4 d-flex gap-2">
        <button type="submit" class="btn btn-primary"><i class="fa-solid fa-upload"></i> Subir horario</button>
        <a href="index.php" class="btn btn-outline-secondary">Cancelar</a>
      </div>
    </form>
  </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
