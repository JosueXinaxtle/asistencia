<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/funciones.php';
requerirLogin();

$pdo = conectarDB();
$horarios = $pdo->query("
  SELECT h.*, p.nombre AS periodo_nombre
  FROM horarios h
  LEFT JOIN periodos p ON p.id = h.periodo_id
  ORDER BY h.subido_en DESC
")->fetchAll();

$tituloPagina = 'Horarios de clase';
require __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
  <h3 class="titulo-seccion mb-0">Horarios de clase</h3>
  <?php if (esAdmin()): ?>
  <a href="subir.php" class="btn btn-primary"><i class="fa-solid fa-upload"></i> Subir horario</a>
  <?php endif; ?>
</div>

<?php mostrarMensaje(); ?>

<div class="card">
  <div class="table-responsive">
    <table class="table table-hover mb-0">
      <thead>
        <tr>
          <th>Grupo</th>
          <th>Especialidad</th>
          <th>Turno</th>
          <th>Periodo</th>
          <th>Archivo</th>
          <th>Subido</th>
          <th>Acciones</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!$horarios): ?>
          <tr><td colspan="7" class="text-center text-muted py-4">No hay horarios cargados todavía.</td></tr>
        <?php endif; ?>
        <?php foreach ($horarios as $h): ?>
        <tr>
          <td><?= htmlspecialchars($h['grupo']) ?></td>
          <td><?= htmlspecialchars($h['especialidad']) ?></td>
          <td><?= htmlspecialchars($h['turno']) ?></td>
          <td><?= htmlspecialchars($h['periodo_nombre'] ?: '—') ?></td>
          <td><i class="fa-solid fa-file-lines"></i> <?= htmlspecialchars($h['nombre_archivo']) ?></td>
          <td><?= date('d/m/Y', strtotime($h['subido_en'])) ?></td>
          <td class="text-nowrap">
            <a href="descargar.php?id=<?= $h['id'] ?>" class="btn btn-sm btn-outline-primary" title="Descargar"><i class="fa-solid fa-download"></i></a>
            <?php if (esAdmin()): ?>
            <a href="eliminar.php?id=<?= $h['id'] ?>" class="btn btn-sm btn-outline-danger btn-eliminar" data-nombre="<?= htmlspecialchars($h['nombre_archivo']) ?>" title="Eliminar"><i class="fa-solid fa-trash"></i></a>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
