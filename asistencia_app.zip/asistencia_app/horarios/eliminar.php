<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/funciones.php';
requerirAdmin();

$pdo = conectarDB();
$id = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare("SELECT * FROM horarios WHERE id = ?");
$stmt->execute([$id]);
$horario = $stmt->fetch();

if ($horario) {
    $ruta = __DIR__ . '/../uploads/horarios/' . $horario['ruta_archivo'];
    if (file_exists($ruta)) unlink($ruta);
    $pdo->prepare("DELETE FROM horarios WHERE id = ?")->execute([$id]);
}

redirigirConExito('index.php', 'Horario eliminado correctamente.');
